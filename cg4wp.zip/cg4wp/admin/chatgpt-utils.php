<?php

function license_expiration(){
   $end_date_str = get_option('chatgpt_end_date', false);
   if(!$end_date_str == ''){
    $end_date = new DateTime($end_date_str);
    $current_date = new DateTime();

    if ($current_date > $end_date) {
        // Current date is greater than the expiry date, so the license has expired
        if (isset($_GET['page']) && $_GET['page'] === 'chatgpt-license-settings') {
            // On the settings page, display a message about the expired license
            echo "Your License has Expired";
        } else {
            // Not on the settings page, show a popup with an upgrade button
            ?>
            <div class="popup-container" id="popup-container" style="display: block;">
                <div class="popup-wrap" style="width: 600px; height: 60%">
                    <h2 style="text-align:center">Your License has Expired,Click here to Upgrade</h2>
                    <a href="https://chatgpt4wordpress.com/pricing/" class="upgradebutton">Upgrade</a>
                </div>
            </div>
            <?php
        }
    } else {
        // Current date is less than the expiry date, so calculate remaining days
        $remaining_days = $current_date->diff($end_date)->days;
        echo "Your Trial Ends in " . $remaining_days . " Days";
    }


}
}
