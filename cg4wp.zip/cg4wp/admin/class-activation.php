<?php

/**
 * Class for checking ChatGPT activation status.
 */
class CGPT_Check_Status {

	public function __construct() {
		add_action( 'admin_init', [ $this, 'check_activation_status' ] );
		$this->load_templates();
		$this->create_table();
		
	}

	/**
	 * @return void
	 */
	public function load_templates(): void {
		require_once PLUGIN_PATH . 'templates/settings/chatgpt-plugin-license.php';
		//if ( get_option( 'chatgpt_client_activated' ) ) {
			require_once PLUGIN_PATH . 'templates/chatgpt-prompt-library.php';
			require_once PLUGIN_PATH . 'templates/posts/create-posts.php';
			
			require_once PLUGIN_PATH . 'templates/posts/rewrite-posts.php';
			require_once PLUGIN_PATH . 'templates/posts/review-posts.php';
			require_once PLUGIN_PATH . 'templates/posts/translate-posts.php';
			
			
			
			require_once PLUGIN_PATH . 'templates/products/translate-products.php';
			require_once PLUGIN_PATH . 'templates/products/rewrite-products.php';
			require_once PLUGIN_PATH . 'templates/products/review-products.php';
			
			
		//}
	}
	
	public function create_table(): void {
		 global $wpdb;

    $table_name = $wpdb->prefix . 'prompts_library';

    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE $table_name (
        id INT NOT NULL AUTO_INCREMENT,
        prompt_title VARCHAR(255) NOT NULL,
        prompt_category VARCHAR(255),
		prompt_text VARCHAR(255),
		auth VARCHAR(255),
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
	}



	/**
	 * @return void
	 */
	public function check_activation_status(): void {
		$this->load_dependencies();
		if ( ! get_option( 'chatgpt_client_activated' ) ) {
			add_action( 'admin_notices', [ $this, 'activation_notice' ] );
		} else {
			
		}
	}

	/**
	 * @return void
	 */
	public function activation_notice(): void {
		?>
		<div class="notice notice-warning is-dismissible">
			<p>
				<?php echo __( 'Please activate the ChatGPT 4 Wordpress plugin to use it.', 'chatgpt' ); ?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=chatgpt-license-settings' ) ); ?>">
					<?php _e( 'Activate', 'chatgpt' ); ?>
				</a>
			</p>
		</div>
		<?php
	}

	public function load_dependencies(): void {
		require_once 'class-configuration.php';
		if (! in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
			add_action( 'admin_notices', [ $this, 'woocommerce_check' ] );
		}
	}

	/**
	 * Display a notice to the user that WooCommerce is required
	 *
	 * @return void
	 */
	public function woocommerce_check(): void {
		?>
		<div class="notice notice-error is-dismissible">
			<p><?php _e( 'ChatGPT Rewriter requires WooCommerce to be installed and activated.', 'chatgpt' ); ?></p>
		</div>
		<?php
	}

}

new CGPT_Check_Status();
