<?php

function add_custom_button_near_filter() {
    global $typenow; // Get the current post type
   $plugin_dir = __DIR__;
         $image_url = site_url( ) . '/wp-content/plugins/cg4wp/assets/images/Icon-logo.png';
    // Check if we are in the 'post' post type
	//if (  get_option( 'chatgpt_client_activated' ) ) {
    if ($typenow == 'post') {
        ?>
		
       <div class="alignleft actions">
            <button class="custom-dropdown-button">
			<img src="<?php echo $image_url;?>">ChatGpt4Wordpress <div class="chevron down"></div></button>
<div class="custom-dropdown-content" style="display:none">
<a href="<?php echo admin_url('admin.php?page=chatgpt_create_posts'); ?>">Create New Posts</a>
<div id="rewritepost" onclick="rewrite_posts()">Re-write Posts</div>
<div id="reviewpost" onclick="review_posts()">Create Comments</div>
<div id="translatepost" onclick="translate_posts()">Translate Posts</div>

            </div>
        </div>
		<script>
		 
function rewrite_posts() {
    // Initialize an array to store the selected post IDs
    const selectedPostIds = [];

    // Find all checkboxes with the name "post[]"
    jQuery('input[name="post[]"]').each(function() {
        if (jQuery(this).is(':checked')) {
            // Get the post ID from the checkbox value
            const postId = jQuery(this).val();
            selectedPostIds.push(postId);
        }
    });

    // Now, the selectedPostIds array contains the values of the checked checkboxes
    console.log(selectedPostIds);

    // Check if at least one checkbox is checked
    if (selectedPostIds.length > 0) {
        // At least one checkbox is checked, you can perform your desired action here
        // For example, you can redirect to another page with the selected post IDs
        const redirectUrl = '<?php echo admin_url('admin.php?page=chatgpt_rewrite_posts'); ?>';
        window.location.href = redirectUrl + '&selected_post_ids=' + selectedPostIds.join(',');
    } else {
        // No checkboxes are checked, show an alert
        alert('No checkboxes are checked.');
    }
}

function review_posts() {
    // Initialize an array to store the selected post IDs
    const selectedPostIds = [];

    // Find all checkboxes with the name "post[]"
    jQuery('input[name="post[]"]').each(function() {
        if (jQuery(this).is(':checked')) {
            // Get the post ID from the checkbox value
            const postId = jQuery(this).val();
            selectedPostIds.push(postId);
        }
    });

    // Now, the selectedPostIds array contains the values of the checked checkboxes
    console.log(selectedPostIds);

    // Check if at least one checkbox is checked
    if (selectedPostIds.length > 0) {
        // At least one checkbox is checked, you can perform your desired action here
        // For example, you can redirect to another page with the selected post IDs
        const redirectUrl = '<?php echo admin_url('admin.php?page=chatgpt_review_posts'); ?>';
        window.location.href = redirectUrl + '&selected_post_ids=' + selectedPostIds.join(',');
    } else {
        // No checkboxes are checked, show an alert
        alert('No checkboxes are checked.');
    }
}

function translate_posts() {
    // Initialize an array to store the selected post IDs
    const selectedPostIds = [];

    // Find all checkboxes with the name "post[]"
    jQuery('input[name="post[]"]').each(function() {
        if (jQuery(this).is(':checked')) {
            // Get the post ID from the checkbox value
            const postId = jQuery(this).val();
            selectedPostIds.push(postId);
        }
    });

    // Now, the selectedPostIds array contains the values of the checked checkboxes
    console.log(selectedPostIds);

    // Check if at least one checkbox is checked
    if (selectedPostIds.length > 0) {
        // At least one checkbox is checked, you can perform your desired action here
        // For example, you can redirect to another page with the selected post IDs
        const redirectUrl = '<?php echo admin_url('admin.php?page=chatgpt_translate_posts'); ?>';
        window.location.href = redirectUrl + '&selected_post_ids=' + selectedPostIds.join(',');
    } else {
        // No checkboxes are checked, show an alert
        alert('No checkboxes are checked.');
    }
}


</script>
        <?php
    }
	
	    // Check if we are in the 'post' post type
    if ($typenow == 'product') {
        ?>
       <div class="alignleft actions">
            <button class="custom-dropdown-button">
			<img src="<?php echo $image_url;?>">ChatGpt4Wordpress <div class="chevron down"></div></button>
            <div class="custom-dropdown-content" style="display:none">
<div id="rewriteproducts" onclick="rewrite_products()">Re-write Products</div>

<div id="reviewproducts" onclick="review_products()">Review Products</div>
<div id="translateproducts" onclick="translate_products()">Translate Products</div>

            </div>
        </div>
        <?php
    }
	
	?>
			<script>
		 

function rewrite_products() {
    // Initialize an array to store the selected post IDs
    const selectedPostIds = [];

    // Find all checkboxes with the name "post[]"
    jQuery('input[name="post[]"]').each(function() {
        if (jQuery(this).is(':checked')) {
            // Get the post ID from the checkbox value
            const postId = jQuery(this).val();
            selectedPostIds.push(postId);
        }
    });

    // Now, the selectedPostIds array contains the values of the checked checkboxes
    console.log(selectedPostIds);

    // Check if at least one checkbox is checked
    if (selectedPostIds.length > 0) {
        // At least one checkbox is checked, you can perform your desired action here
        // For example, you can redirect to another page with the selected post IDs
        const redirectUrl = '<?php echo admin_url('admin.php?page=chatgpt_rewrite_products'); ?>';
        window.location.href = redirectUrl + '&selected_post_ids=' + selectedPostIds.join(',');
    } else {
        // No checkboxes are checked, show an alert
        alert('No checkboxes are checked.');
    }
}

function review_products() {
    // Initialize an array to store the selected post IDs
    const selectedPostIds = [];

    // Find all checkboxes with the name "post[]"
    jQuery('input[name="post[]"]').each(function() {
        if (jQuery(this).is(':checked')) {
            // Get the post ID from the checkbox value
            const postId = jQuery(this).val();
            selectedPostIds.push(postId);
        }
    });

    // Now, the selectedPostIds array contains the values of the checked checkboxes
    console.log(selectedPostIds);

    // Check if at least one checkbox is checked
    if (selectedPostIds.length > 0) {
        // At least one checkbox is checked, you can perform your desired action here
        // For example, you can redirect to another page with the selected post IDs
        const redirectUrl = '<?php echo admin_url('admin.php?page=chatgpt_review_products'); ?>';
        window.location.href = redirectUrl + '&selected_post_ids=' + selectedPostIds.join(',');
    } else {
        // No checkboxes are checked, show an alert
        alert('No checkboxes are checked.');
    }
}

function translate_products() {
    // Initialize an array to store the selected post IDs
    const selectedPostIds = [];

    // Find all checkboxes with the name "post[]"
    jQuery('input[name="post[]"]').each(function() {
        if (jQuery(this).is(':checked')) {
            // Get the post ID from the checkbox value
            const postId = jQuery(this).val();
            selectedPostIds.push(postId);
        }
    });

    // Now, the selectedPostIds array contains the values of the checked checkboxes
    console.log(selectedPostIds);

    // Check if at least one checkbox is checked
    if (selectedPostIds.length > 0) {
        // At least one checkbox is checked, you can perform your desired action here
        // For example, you can redirect to another page with the selected post IDs
        const redirectUrl = '<?php echo admin_url('admin.php?page=chatgpt_translate_products'); ?>';
        window.location.href = redirectUrl + '&selected_post_ids=' + selectedPostIds.join(',');
    } else {
        // No checkboxes are checked, show an alert
        alert('No checkboxes are checked.');
    }
}

</script>
	
<?php	
}
add_action('restrict_manage_posts', 'add_custom_button_near_filter');

