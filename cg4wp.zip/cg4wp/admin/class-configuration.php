<?php

class CGPT_System_Boot {

	public function __construct() {
		add_action( 'admin_enqueue_scripts', [
			$this,
			'cgpt_add_script_support',
		] );
		
		$this->load_modules();
		add_action( 'wp_ajax_check_plugin_activation', [
			$this,
			'check_plugin_activation',
		] );
		
		add_action( 'wp_ajax_eligibility_check', [
			$this,
			'eligibility_check',
		] );
		
		add_action( 'wp_ajax_update_requests_counts', [
			$this,
			'update_requests_counts',
		] );
		
		
	}


    public function check_plugin_activation(): void {
	
   if (  get_option( 'chatgpt_client_activated' ) ) {
        echo 'activated';
    } else {
        echo 'not-activated';
    }

    wp_die(); // Always include this to terminate the response
	}
	/**
	 * Adds Custom Scripts
	 *
	 * @return void
	 */
	public function cgpt_add_script_support(): void {
		wp_enqueue_style( 'cgpt-css', PLUGIN_DIR_PATH . 'assets/css/app.css', '', date('d h:i:s') );
		wp_enqueue_script( 'cgpt-js', PLUGIN_DIR_PATH . 'assets/js/app.js', [ 'jquery' ], date('d h:i:s'), TRUE );
		wp_localize_script( 'cgpt-js', 'cgpt_posts', [
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		] );
		 wp_enqueue_style('inter-font', 'https://fonts.googleapis.com/css2?family=Inter:wght@300&display=swap', array(), null);

	}

	/**
	 * Loading Plugin Functionality
	 *
	 * @return void
	 */
	public function load_modules(): void {
		$this->load_product_modules();
		$this->load_post_modules();
	}

	/**
	 * Product Modules
	 *
	 * @return void
	 */
	public function load_product_modules(): void {
		
		require_once 'core/products/class-rewrite.php';
		require_once 'core/products/class-review.php';
		require_once 'core/products/class-translate.php';
		//require_once 'admin/chatgpt-utils.php';
		require_once plugin_dir_path(__FILE__) . '/chatgpt-utils.php';
	}

	/**
	 * Post Modules
	 *
	 * @return void
	 */
	public function load_post_modules(): void {
		require_once 'core/posts/class-rewrite.php';
		require_once 'core/posts/class-review.php';
		require_once 'core/posts/class-create-post.php';
		require_once 'core/posts/class-translate.php';
		require_once 'class-colomn-button.php';
		
	}
	    /**
	 * Handle form submission and API verification.
	 */
	public function update_requests_counts(){
		if ( isset( $_POST['requestcount'] )  ) {
			        $request_count  = $_POST['requestcount'];
			        
				   $api_response = $this->requests_counts( $request_count );
                   if ( $api_response !== NULL ) {
				   
				    $remaining_usuage   = $api_response->remaining_usuage;
					$message            = $api_response->message;
					
					
					$response_data = array(
					'remaining_usuage' => $remaining_usuage,
					'message'    => $message,
					);
                     wp_send_json($response_data);
					 
				
			
			} else {
				$error_message = 'Error: Failed to get API response.';
				$response_data = array(
                    'message' => $error_message,);
                     wp_send_json($response_data);
			}

	}
	
	}

/**
	 * Helper function to check the available limit and license status.
	 *
	 * @param string $license_key The license key to verify.
	 *
	 */
	 
	 	private function requests_counts( INT $request_count ): stdClass  {
			
		$api_url  = CHATGPT_SERVER_URL . '/update_requests_counts';
		$license_key = get_option('chatgpt_license_key');
        
		$response = wp_remote_post($api_url, [
                    'method'  => 'POST',
                    'headers' => [
                    'Content-Type' => 'application/json',
                    ],
                    'body'    => json_encode([
                    'api_key'  => $license_key,
                    'requests' => $request_count,
                 ]),
            ]);
return json_decode(wp_remote_retrieve_body($response));
		}
	
    /**
	 * Handle form submission and API verification.
	 */
	public function eligibility_check(){
		if ( isset( $_POST['requestcount'] )  ) {
			
			$requestcount  = sanitize_text_field( $_POST['requestcount'] );
			$api_response = $this->verify_license_eligibility_check( $requestcount );
			 
			 $license_key = get_option('chatgpt_license_key');
			 
			if ( $api_response !== NULL ) {
				   
				    $error_type         = $api_response->error_type;
					$status             = $api_response->status;
					$api_key            = $api_response->chatgpt_api_key;
				    $message            = $api_response->message;
					
				    if($error_type == 'eligible'){
						
						if(get_option( 'unlimited_product') == 'yes' ){
							
							//update_option( 'chatgpt_api_key', '' );
							$response_data = array(
					       'error_type' => 'eligible',
						   'popup' => '',
					       'status'     => $status,
                           'message'    => 'Every thing is fine', );
                            wp_send_json($response_data);
							
						}
						
						if(get_option( 'unlimited_product') == 'no' && $api_key == ''){
							
							update_option( 'chatgpt_api_key', '' );
							update_option( 'unlimited_product', 'yes' );
							$response_data = array(
					       'error_type' => 'eligible',
						   'popup'      => 'show',
					       'status'     => $status,
                           'message'    => 'Please update the ChatGpt APi key', );
                            wp_send_json($response_data);
							
						}
						
						
							if(get_option( 'unlimited_product') == 'no' && !empty($api_key)){
							
							update_option( 'chatgpt_api_key', $api_key );
							$response_data = array(
					       'error_type' => 'eligible',
						    'popup'      => '',
					       'status'     => $status,
                           'message'    => 'Key is updated', );
                            wp_send_json($response_data);
							
						}
						
						
						
						}
						
					}else{
						update_option( 'chatgpt_api_key', $api_key );
						$response_data = array(
					       'error_type' => 'noeligible',
					       'status'     => $status,
                           'message'    => $message,
					);
                     wp_send_json($response_data);
						
			         }
			
			} else {
				$error_message = 'Error: Failed to get API response.';
				$response_data = array(
                    'message' => $error_message,);
                     wp_send_json($response_data);
			}
		
		

	}

	
	private function verify_license_eligibility_check( INT $request_count ): stdClass  {
		$api_url  = CHATGPT_SERVER_URL . '/eligibility_check';
		$license_key = get_option('chatgpt_license_key');

		$response = wp_remote_post($api_url, [
    'method'  => 'POST',
    'headers' => [
        'Content-Type' => 'application/json',
    ],
    'body'    => json_encode([
        'api_key'  => $license_key,
        'requests' => $request_count,
    ]),
]);



return json_decode(wp_remote_retrieve_body($response));

		
	}





}

new CGPT_System_Boot();
