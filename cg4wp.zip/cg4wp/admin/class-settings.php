<?php

/**
 * Plugin settings page class.
 */
class ChatGPT_Settings_Page {

	public function __construct() {
		$this->load_templates();
	}

	public function load_templates(): void {
		require_once PLUGIN_PATH . 'templates/settings/chatgpt-plugin-license.php';
		//if ( get_option( 'chatgpt_client_activated' )) {
			require_once PLUGIN_PATH . 'templates/chatgpt-prompt-library.php';

			
		//}
	}
	
	

}

new ChatGPT_Settings_Page();
