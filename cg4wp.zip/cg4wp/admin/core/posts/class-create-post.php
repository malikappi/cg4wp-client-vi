<?php

class CGPT_Post_Creator {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'restrict_manage_posts', [
			$this,
			'cgpt_add_rewrite_button',
		] );
		
		add_action( 'admin_init', [ $this, 'send_chatgpt_prompt' ] );
		
		add_action( 'wp_ajax_nopriv_process_row', [
			$this,
			'process_row',
		] );
		
		add_action( 'wp_ajax_process_row', [
			$this,
			'process_row',
		] );
		
		add_action( 'wp_ajax_process_row_php', [
			$this,
			'process_row_php',
		] );
		
	}

	/**
	 * Popup for Rewrite with ChatGPT
	 *
	 * @return void
	 */
	public function cgpt_add_rewrite_button(): void {
		require_once PLUGIN_DIR . '/templates/posts/create-posts.php';
	}

	/**
	 * API call for ChatGPT
	 *
	 * @param string $prompt
	 *
	 * @return object|string $response_data
	 */
	private function send_chatgpt_prompt( string $prompt , int $token ) {
		$api_key = get_option( 'chatgpt_api_key' );
		$url     = 'https://api.openai.com/v1/chat/completions';

		$data = [
			'model'       => 'gpt-3.5-turbo',
			'messages'    => [
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			],
			'temperature' => 0.7,
			"max_tokens"  => $token,
			"n"           => 1,
		];

		$headers = [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		];

		$options = [
			'http' => [
				'header'  => $headers,
				'method'  => 'POST',
				'content' => json_encode( $data ),
			],
		];

		$context  = stream_context_create( $options );
		$response = file_get_contents( $url, FALSE, $context );

		if ( $response === FALSE ) {
			// Handle error
			return 'Error: Failed to connect to the ChatGPT API';
		}

		$response_data = json_decode( $response, TRUE );

		if ( $response_data['choices'][0]['message']['content'] ) {
			return $response_data['choices'][0]['message']['content'];
		}

		// Handle error
		return 'Error: Failed to retrieve response from the ChatGPT API';
	}

	 	
    public function process_row(): void  {
        global $wpdb;
       
        $keyword = sanitize_text_field($_POST['keyword']);
        $prompt = $_POST['prompt'];

        $table_name = $wpdb->prefix . 'prompts_library'; // Replace with your table name
        $prompt_id = intval($prompt); // Assuming $prompt is the ID, convert it to an integer for safety

        // Use a prepared statement to fetch the row based on the ID
        $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $prompt_id);
        $prompt_row = $wpdb->get_row($query);

        if ($prompt_row) {
        $prompt_text = $prompt_row->prompt_text; // Access the prompt_text property
        } else {
        // Handle the case where no row was found with the given ID
        $prompt_text = "Prompt not found";
        }

        $prompt = str_replace("[[keyword]]", $keyword, $prompt_text);
		
		
		
		$content_prompt = "Write the post content according to given prompt, pick the keyword from prompt and prompt is below $prompt";
		
        
		$content = $this->send_chatgpt_prompt($content_prompt , 1000);
		
		$title_prompt = "Write the post title according to given content and give only one title without order list and the content is below $content ";
		
		$title = $this->send_chatgpt_prompt($title_prompt , 50);
 

// The prompts instructing the model to generate a post title and content


    $response_data = array(
        'title' => $title,
        'content' => $content,
    );

    
        wp_send_json($response_data);
   


// Don't forget to exit
wp_die();

}


public function process_row_php(): void {
    // Get data from the AJAX request
    $post_title = $_POST['post_title'];
    $post_content = $_POST['post_content'];
    $action = $_POST['argument']; // Use 'action' instead of 'argument'

    // Create or draft the post
    $post_data = array(
        'post_title' => $post_title,
        'post_content' => $post_content,
        'post_status' => ($action === 'publish') ? 'publish' : 'draft', // Set post status based on action
        'post_type' => 'post', // You can change the post type if needed
    );

    // Insert the post into the database
    $post_id = wp_insert_post($post_data);

    if (!is_wp_error($post_id)) {
        // Post created successfully
        $response = array(
            'status' => 'success',
            'message' => 'Post ' . ucfirst($action) . 'ed successfully!',
            'post_id' => $post_id,
        );
    } else {
        // Error occurred while creating the post
        $error_message = $post_id->get_error_message();
        $response = array(
            'status' => 'error',
            'message' => 'Failed to ' . $action . ' the post. Error: ' . $error_message,
        );
    }

    // Return the response as JSON
   header('Content-Type: application/json');
echo json_encode($response);
    wp_die(); // Ensure that WordPress exits after sending the response
}



}

new CGPT_Post_Creator();