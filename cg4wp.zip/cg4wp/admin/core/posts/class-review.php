<?php

class CGPT_Post_Review {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'restrict_manage_posts', [
			$this,
			'cgpt_add_review_button',
		] );
		add_action( 'wp_ajax_request_add_post_reviews', [
			$this,
			'request_add_post_reviews',
		] );
		add_action( 'wp_ajax_rewrite_process_row_comments', [
			$this,
			'rewrite_process_row_comments',
		] );
		add_action( 'admin_enqueue_scripts', [ $this, 'add_review_scripts' ] );
	}

	public function add_review_scripts(): void {
		//wp_enqueue_script( 'cgpt-review-js', PLUGIN_PATH . 'assets/js/review.js', [ 'jquery' ], '1.0', TRUE );
		wp_localize_script( 'cgpt-review-js', 'cgpt_reviews', [
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		] );
	}

	/**
	 * Popup for Review with ChatGPT
	 *
	 * @return void
	 */
	public function cgpt_add_review_button(): void {
		require_once PLUGIN_DIR . '/templates/posts/review-posts.php';
	}

	/**
	 * API call for ChatGPT
	 *
	 * @param string $prompt
	 *
	 * @return object|string $response_data
	 */
private function send_chatgpt_prompt( string $prompt , int $token ) {
		$api_key = get_option( 'chatgpt_api_key' );
		$url     = 'https://api.openai.com/v1/chat/completions';

		$data = [
			'model'       => 'gpt-3.5-turbo',
			'messages'    => [
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			],
			'temperature' => 0.7,
			"max_tokens"  => $token,
			"n"           => 1,
		];

		$headers = [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		];

		$options = [
			'http' => [
				'header'  => $headers,
				'method'  => 'POST',
				'content' => json_encode( $data ),
			],
		];

		$context  = stream_context_create( $options );
		$response = file_get_contents( $url, FALSE, $context );

		if ( $response === FALSE ) {
			// Handle error
			return 'Error: Failed to connect to the ChatGPT API';
		}

		$response_data = json_decode( $response, TRUE );

		if ( $response_data['choices'][0]['message']['content'] ) {
			return $response_data['choices'][0]['message']['content'];
		}

		// Handle error
		return 'Error: Failed to retrieve response from the ChatGPT API';
	}

	/**
	 * Parses the post name
	 *
	 * @param string $input
	 * @param int $post_id
	 *
	 * @return string $input
	 */
	public function cgpt_filter_input( int $post_id, string $input ): string {
		$post_title = '';

		if ( $post = wc_get_post( $post_id ) ) {
			$post_title = $post->get_name();
		}

		return str_replace( '[[post_title]]', $post_title, $input );
	}

	/**
	 * Check if the response contains unwanted messages
	 *
	 * @param string $response
	 *
	 * @return bool
	 */
	private function is_unwanted_response( string $response ): bool {
		$unwanted_messages = [
			"AI model",
			"I'm sorry",
			"AI language model",
			"Failed to connect to the ChatGPT API",
		];

		foreach ( $unwanted_messages as $message ) {
			if ( stripos( $response, $message ) !== FALSE ) {
				return TRUE;
			}
		}

		return FALSE;
	}

	
	public function request_add_post_reviews(): void {
         global $wpdb;
         $post_id = $_POST['post_id'];
         $post_title = sanitize_text_field($_POST['post_title']);
         $prompt = sanitize_text_field($_POST['prompt']);
         $table_name = $wpdb->prefix . 'prompts_library'; // Replace with your table name
         $prompt_id = intval($prompt); // Assuming $prompt is the ID, convert it to an integer for safety

         // Use a prepared statement to fetch the row based on the ID
         $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $prompt_id);
         $prompt_row = $wpdb->get_row($query);

         if ($prompt_row) {
             $prompt_text = $prompt_row->prompt_text; // Access the prompt_text property
          } else {
            // Handle the case where no row was found with the given ID
          $prompt_text = "Prompt not found";
          }
          $post_content = get_post_field('post_content', $post_id);
         
          $comment_prompt = str_replace("[[post_content]]", $post_content, $prompt_text);


$content_prompt = "Write the post comments related to below prompt: $comment_prompt"; // Separate prompt for content
$comment = $this->send_chatgpt_prompt($comment_prompt , 80);


    $response_data = array(
        'title' => $post_title,
        'comments' => $comment,
    );

        wp_send_json($response_data);
  


// Don't forget to exit
wp_die();

}




public function rewrite_process_row_comments(): void {
    // Get data from the AJAX request
    $post_id = $_POST['post_id'];
   
    $post_comments = $_POST['comments'];
    $action = $_POST['argument']; // Use 'action' instead of 'argument'
// Generate a random commenter name
$commenter_name = 'User' . rand(100, 999);

// Set the comment data
$comment_data = array(
    'comment_post_ID' => $post_id,  // Replace with your post ID
    'comment_author' => $commenter_name, // Use the generated name
    'comment_content' => $post_comments,  // Replace with your comment content
    'comment_approved' => 1,  // Approve the comment (change as needed)
);

// Insert the comment
$comment_id = wp_insert_comment($comment_data);

    // Create an array of post data to update
    $post_data = array(
        'ID' => $post_id, // Specify the post ID to update
        'post_status' => ($action === 'publish') ? 'publish' : 'draft', // Set post status based on action
    );

    // Update the post title and content
    $updated_post_id = wp_update_post($post_data, true);

    if (!is_wp_error($updated_post_id)) {
        // Post title and content updated successfully
        $new_permalink = get_permalink($updated_post_id);
        
        // No need to update post_name and guid; WordPress handles permalinks automatically
        
        $response = array(
            'status' => 'success',
            'message' => 'Post ' . ucfirst($action) . 'ed successfully!',
            'post_id' => $post_id,
        );
    } else {
        $error_message = $updated_post_id->get_error_message();
        $response = array(
            'status' => 'error',
            'message' => 'Failed to ' . $action . ' the post. Error: ' . $error_message,
        );
    }

    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    wp_die(); // Ensure that WordPress exits after sending the response
}

	


}
new CGPT_Post_Review();
