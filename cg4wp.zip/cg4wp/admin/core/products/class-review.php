<?php

class CGPT_Product_tranlate {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'restrict_manage_posts', [
			$this,
			'cgpt_add_review_button',
		] );;
		add_action( 'wp_ajax_request_add_product_reviews', [
			$this,
			'request_add_product_reviews',
		] );
		
		add_action( 'wp_ajax_product_process_row_comments', [
			$this,
			'product_process_row_comments',
		] );
		
		add_action( 'admin_enqueue_scripts', [ $this, 'add_review_scripts' ] );
	}

	public function add_review_scripts(): void {
		//wp_enqueue_script( 'cgpt-review-js', PLUGIN_PATH . 'assets/js/review.js', [ 'jquery' ], '1.0', TRUE );
		wp_localize_script( 'cgpt-review-js', 'cgpt_reviews', [
			'ajaxurl' => admin_url( 'admin-ajax.php' ),
		] );
	}

	/**
	 * Popup for Review with ChatGPT
	 *
	 * @return void
	 */
	public function cgpt_add_review_button(): void {
		require_once PLUGIN_DIR . '/templates/products/review-products.php';
	}

	/**
	 * API call for ChatGPT
	 *
	 * @param string $prompt
	 *
	 * @return object|string $response_data
	 */
private function send_chatgpt_prompt( string $prompt , int $token ) {
		$api_key = get_option( 'chatgpt_api_key' );
		$url     = 'https://api.openai.com/v1/chat/completions';

		$data = [
			'model'       => 'gpt-3.5-turbo',
			'messages'    => [
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			],
			'temperature' => 0.7,
			"max_tokens"  => $token,
			"n"           => 1,
		];

		$headers = [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		];

		$options = [
			'http' => [
				'header'  => $headers,
				'method'  => 'POST',
				'content' => json_encode( $data ),
			],
		];

		$context  = stream_context_create( $options );
		$response = file_get_contents( $url, FALSE, $context );

		if ( $response === FALSE ) {
			// Handle error
			return 'Error: Failed to connect to the ChatGPT API';
		}

		$response_data = json_decode( $response, TRUE );

		if ( $response_data['choices'][0]['message']['content'] ) {
			return $response_data['choices'][0]['message']['content'];
		}

		// Handle error
		return 'Error: Failed to retrieve response from the ChatGPT API';
	}

	/**
	 * Parses the product name
	 *
	 * @param string $input
	 * @param int $product_id
	 *
	 * @return string $input
	 */
	public function cgpt_filter_input( int $product_id, string $input ): string {
		$product_title = '';

		if ( $product = wc_get_product( $product_id ) ) {
			$product_title = $product->get_name();
		}

		return str_replace( '{{product_name}}', $product_title, $input );
	}

	/**
	 * Check if the response contains unwanted messages
	 *
	 * @param string $response
	 *
	 * @return bool
	 */
	private function is_unwanted_response( string $response ): bool {
		$unwanted_messages = [
			"AI model",
			"I'm sorry",
			"AI language model",
			"Failed to connect to the ChatGPT API",
		];

		foreach ( $unwanted_messages as $message ) {
			if ( stripos( $response, $message ) !== FALSE ) {
				return TRUE;
			}
		}

		return FALSE;
	}

	
    public function request_add_product_reviews(): void {
    global $wpdb;
    $api_key = sanitize_text_field(get_option('chatgpt_api_key'));
    $post_title = sanitize_text_field($_POST['post_title']);
    $prompt = sanitize_text_field($_POST['prompt']);

    $table_name = $wpdb->prefix . 'prompts_library'; // Replace with your table name
    $prompt_id = intval($prompt); // Assuming $prompt is the ID, convert it to an integer for safety

// Use a prepared statement to fetch the row based on the ID
    $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $prompt_id);
    $prompt_row = $wpdb->get_row($query);

    if ($prompt_row) {
    $prompt_text = $prompt_row->prompt_text; // Access the prompt_text property
    } else {
    // Handle the case where no row was found with the given ID
    $prompt_text = "Prompt not found";
    }

    $comment_prompt = str_replace("[[product_title]]", $post_title, $prompt_text);
		 $comment_prompt = str_replace("[[product_description]]", $post_title, $comment_prompt);


$content_prompt = "write the woocommerce product review in paragraph and give only one review which is related to below prompt: $comment_prompt"; // Separate prompt for content

// Define the API endpoint
$api_url = "https://api.openai.com/v1/engines/text-davinci-002/completions";

// Prepare the data for the API request for title
$data_comment_prompt = [
    "prompt" => $content_prompt,
    "max_tokens" => 500,  // Adjust the number of tokens as needed
    "n" => 1,
    "stop" => null,
    "temperature" => 0.7,  // Adjust the temperature for creativity
];



// Prepare the HTTP headers
$headers = [
    "Authorization: Bearer " . $api_key,
    "Content-Type: application/json",
];

// Initialize cURL sessions for title and content separately

$ch_comment = curl_init($api_url);


// Set cURL options for content
curl_setopt($ch_comment, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch_comment, CURLOPT_POST, true);
curl_setopt($ch_comment, CURLOPT_POSTFIELDS, json_encode($data_comment_prompt)); // Send the content prompt
curl_setopt($ch_comment, CURLOPT_HTTPHEADER, $headers);

// Execute the cURL requests separately

$response_comment = curl_exec($ch_comment);


$error_message_content = curl_error($ch_comment);


curl_close($ch_comment);

 
    $response_data_comment = json_decode($response_comment, true);

    

    // Extract the generated text (post title and content) for content
    $generated_text_comment = $response_data_comment["choices"][0]["text"];

    // Separate the content (after "Content:")
    $comment = trim($generated_text_comment);

    $response_data = array(
        'title' => $post_title,
        'comments' => $comment,
    );

        wp_send_json($response_data);
  


// Don't forget to exit
wp_die();

}




public function product_process_row_comments(): void {
    $product_id = $_POST['post_id'];
    $comment_content = $_POST['comments'];
    $star_rating = 5;
    $action = $_POST['argument'];
// Create a random commenter name
    $commenter_name = 'User' . rand(100, 999);

    // Create the comment data
    $comment_data = array(
        'comment_post_ID' => $product_id,
        'comment_author' => $commenter_name,
        'comment_content' => $comment_content,
        'comment_approved' => 1, // Automatically approve the comment
    );

    // Create a random commenter name
    $commenter_name = 'User' . rand(100, 999);
	
	 // Create the comment data
    $comment_data = array(
        'comment_post_ID' => $product_id,
        'comment_author' => $commenter_name,
        'comment_content' => $comment_content,
        'comment_approved' => 1, // Automatically approve the comment
    );

	// Insert the comment
    $comment_id = wp_insert_comment($comment_data);

   if ($comment_id) {
    update_post_meta($product_id, '_wc_rating', $star_rating);

    // Calculate the new average rating and rating count
    $ratings = get_post_meta($product_id, '_wc_rating', false);
    $rating_count = count($ratings);
    $total_rating = array_sum($ratings);
    $new_average_rating = $rating_count > 0 ? $total_rating / $rating_count : 0;

    // Update the average rating and rating count
    update_post_meta($product_id, '_wc_average_rating', $new_average_rating);
    update_post_meta($product_id, '_wc_rating_count', $rating_count);


    $response = array(
        'status' => 'success',
        'message' => 'Product added successfully!"'.$comment_content.'"',
        'post_id' => $product_id,
    );
} else {
    //$error_message = $comment_id->get_error_message(); // Fix this line
    $response = array(
        'status' => 'error',
        'message' => 'Failed to add feedback to the product. Error: ',
    );
}



    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    wp_die(); // Ensure that WordPress exits after sending the response
}


}

new CGPT_Product_tranlate();
