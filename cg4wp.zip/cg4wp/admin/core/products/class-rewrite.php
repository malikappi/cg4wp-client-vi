<?php

class CGPT_Product_Rewrite {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'restrict_manage_posts', [
			$this,
			'cgpt_add_rewrite_button',
		] );
	
		
		
		add_action( 'wp_ajax_product_fetch_propmt', [
			$this,
			'product_fetch_propmt',
		] );
		
		
		add_action( 'wp_ajax_product_rewrite_process_row', [
			$this,
			'product_rewrite_process_row',
		] );
		
		add_action( 'wp_ajax_product_rewrite_process_row_php', [
			$this,
			'product_rewrite_process_row_php',
		] );
	}

	/**
	 * Popup for Rewrite with ChatGPT
	 *
	 * @return void
	 */
	public function cgpt_add_rewrite_button(): void {
		require_once PLUGIN_DIR . '/templates/products/rewrite-products.php';
	}

	/**
	 * Update Product Permalink
	 *
	 * @param int $product_id
	 *
	 * @return void
	 */
	public function cgpt_update_product_permalink( int $product_id ): void {
		// Get the current product
		$product = wc_get_product( $product_id );

		// Update the post permalink
		$new_slug      = sanitize_title( $product->get_title() );
		$old_permalink = get_permalink( $product_id );
		$new_permalink = str_replace( $product->get_slug(), $new_slug, $old_permalink );

		// Update the post with the new permalink
		$post_data = [
			'ID'        => $product_id,
			'post_name' => $new_slug,
			'guid'      => $new_permalink,
		];
		wp_update_post( $post_data );
	}


/**
	 * API call for ChatGPT
	 *
	 * @param string $prompt
	 *
	 * @return object|string $response_data
	 */
private function send_chatgpt_prompt( string $prompt , int $token ) {
		$api_key = get_option( 'chatgpt_api_key' );
		$url     = 'https://api.openai.com/v1/chat/completions';

		$data = [
			'model'       => 'gpt-3.5-turbo',
			'messages'    => [
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			],
			'temperature' => 0.7,
			"max_tokens"  => $token,
			"n"           => 1,
		];

		$headers = [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		];

		$options = [
			'http' => [
				'header'  => $headers,
				'method'  => 'POST',
				'content' => json_encode( $data ),
			],
		];

		$context  = stream_context_create( $options );
		$response = file_get_contents( $url, FALSE, $context );

		if ( $response === FALSE ) {
			// Handle error
			return 'Error: Failed to connect to the ChatGPT API';
		}

		$response_data = json_decode( $response, TRUE );

		if ( $response_data['choices'][0]['message']['content'] ) {
			return $response_data['choices'][0]['message']['content'];
		}

		// Handle error
		return 'Error: Failed to retrieve response from the ChatGPT API';
	}

	
public function product_fetch_propmt() :void{
     global $wpdb;

    $prompt_id = $_POST['prompt_id'];
    $table_name = $wpdb->prefix . 'prompts_library';

    // Assuming $prompt_id is the ID, convert it to an integer for safety
    $prompt_id = intval($prompt_id);

    // Use a prepared statement to fetch the row based on the ID
    $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $prompt_id);
    $prompt_row = $wpdb->get_row($query);

    if ($prompt_row) {
        $prompt_text = $prompt_row->prompt_text; // Access the prompt_text property
        echo $prompt_text;
    } else {
        // Handle the case where no row was found with the given ID
        echo "Prompt not found";
    }
wp_die(); // 
	
	
	}

public function product_rewrite_process_row(): void  {
  global $wpdb;
   
    $promptype = sanitize_text_field($_POST['promptype']);
    $prompt    = sanitize_text_field($_POST['prompt']);
    $post_id   = sanitize_text_field($_POST['post_id']);

    if ($promptype == 'title') {
        $post = get_post($post_id);

        if ($post) {
            $post_title = $post->post_title;
            $post_content = $post->post_content;
		}
 
         $prompt_title = str_replace("[[product_title]]", $post_title, $prompt);
		
         $title = $this->send_chatgpt_prompt($prompt_title,150);
	   
	  
	   
	   	$short_description = wc_get_product( $post_id )->get_short_description();
        
      
            $response_data = array(
                'title' => $title,
				'shortdescription' => $short_description,
                'content' => $post_content,
            );
                

               
                wp_send_json($response_data);
         
        // Don't forget to exit
        wp_die();
    }


if ($promptype == 'title_body') {
    $post = get_post($post_id);

    if ($post) {
        $post_title = $post->post_title;
        $post_content = $post->post_content;
	}
        $content_prompt1 = str_replace("[[product_title]]", $post_title, $prompt);
        $final_prompt = str_replace("[[product_description]]", $post_content, $content_prompt1);
        
		$content_prompts = "Rewrite the Woocommerce Product Description according to given prompt and the content is '$post_content' and prompt is given below: $final_prompt"; // Separate prompt for content
       $content = $this->send_chatgpt_prompt($content_prompts,2000);
        
       $title_prompt = "Rewrite Woocommerce Product title according to given content, give only one unique title, the content is given below $content"; // Separate prompt for content
       $title = $this->send_chatgpt_prompt($title_prompt,150);
	   
	   
	   
	   	$short_description = wc_get_product( $post_id )->get_short_description();
        if (!empty($short_description)) {
         $shortdesc_prompts = "Rewrite the Woocommerce Product short Description according to given $content"; // Separate prompt for content
        $shortdescription = $this->send_chatgpt_prompt($shortdesc_prompts,200);
         } else {
         $shortdescription = '';
         }
      
            $response_data = array(
                'title' => $title,
				'shortdescription' => $shortdescription,
                'content' => $content,
            );
                
      
            wp_send_json($response_data);
      
        // Don't forget to exit
        wp_die();
    
}


if ($promptype == 'body') {
    $post = get_post($post_id);

    if ($post) {
        $post_title = $post->post_title;
        $post_content = $post->post_content;
	}
         $content_prompt1 = str_replace("[[product_title]]", $post_title, $prompt);
        $final_prompt = str_replace("[[product_description]]", $post_content, $content_prompt1);
		
	
	   $content_prompts = "Rewrite the Woocommerce Product Description according to given prompt and the content is '$post_content' and prompt is given below: $final_prompt"; // Separate prompt for content
       $content = $this->send_chatgpt_prompt($content_prompts,2000);
	   
	   	$short_description = wc_get_product( $post_id )->get_short_description();
        if (!empty($short_description)) {
         $shortdesc_prompts = "Rewrite the Woocommerce Product short Description according to given prompt, the short Description is '$short_description' and prompt is given below: $final_prompt"; // Separate prompt for content
        $shortdescription = $this->send_chatgpt_prompt($shortdesc_prompts,200);
         } else {
         $shortdescription = '';
         }
      
            $response_data = array(
                'title' => $post_title,
				'shortdescription' => $short_description,
                'content' => $content,
            );
                
      
            wp_send_json($response_data);
      
        // Don't forget to exit
        wp_die();
       

}

}

public function product_rewrite_process_row_php(): void {
    // Get data from the AJAX request
    $post_id = $_POST['post_id'];
    $post_title = $_POST['post_title'];
	$postshort = $_POST['postshort'];
    $post_content = $_POST['post_content'];
    $action = $_POST['argument']; // Use 'action' instead of 'argument'

    // Create an array of post data to update
    $post_data = array(
        'ID' => $post_id, // Specify the post ID to update
        'post_title' => $post_title, // New post title
        'post_content' => $post_content, // New post content
        'post_status' => ($action === 'publish') ? 'publish' : 'draft', // Set post status based on action
    );

    // Update the post title and content
    $updated_post_id = wp_update_post($post_data, true);

    if (!is_wp_error($updated_post_id)) {
		
		$product = wc_get_product($post_id);
		$product->set_short_description($postshort);
        $product->save();
        // Post title and content updated successfully
        $new_permalink = get_permalink($updated_post_id);
        
        // No need to update post_name and guid; WordPress handles permalinks automatically
        
        $response = array(
            'status' => 'success',
            'message' => 'Post ' . ucfirst($action) . 'ed successfully!',
            'post_id' => $post_id,
        );
    } else {
        $error_message = $updated_post_id->get_error_message();
        $response = array(
            'status' => 'error',
            'message' => 'Failed to ' . $action . ' the post. Error: ' . $error_message,
        );
    }

    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
    wp_die(); // Ensure that WordPress exits after sending the response
}

	
}

new CGPT_Product_Rewrite();