<?php

class CGPT_Product_translator {

	/**
	 * Constructor
	 */
	public function __construct() {
		add_action( 'restrict_manage_posts', [
			$this,
			'cgpt_post_translate_template',
		] );
		
		
		add_action( 'wp_ajax_fetch_propmt', [
			$this,
			'fetch_propmt',
		] );
		
		
		add_action( 'wp_ajax_translate_process_row', [
			$this,
			'translate_process_row',
		] );
		
		add_action( 'wp_ajax_translate_process_row_php', [
			$this,
			'translate_process_row_php',
		] );
	}

	public function cgpt_post_translate_template(): void {
		require_once PLUGIN_DIR . '/templates/products/translate-products.php';
	}

	
	/**
	 * API call for ChatGPT
	 *
	 * @param string $prompt
	 *
	 * @return object|string $response_data
	 */
private function send_chatgpt_prompt( string $prompt , int $token ) {
		$api_key = get_option( 'chatgpt_api_key' );
		$url     = 'https://api.openai.com/v1/chat/completions';

		$data = [
			'model'       => 'gpt-3.5-turbo',
			'messages'    => [
				[
					'role'    => 'user',
					'content' => $prompt,
				],
			],
			'temperature' => 0.7,
			"max_tokens"  => $token,
			"n"           => 1,
		];

		$headers = [
			'Content-Type: application/json',
			'Authorization: Bearer ' . $api_key,
		];

		$options = [
			'http' => [
				'header'  => $headers,
				'method'  => 'POST',
				'content' => json_encode( $data ),
			],
		];

		$context  = stream_context_create( $options );
		$response = file_get_contents( $url, FALSE, $context );

		if ( $response === FALSE ) {
			// Handle error
			return 'Error: Failed to connect to the ChatGPT API';
		}

		$response_data = json_decode( $response, TRUE );

		if ( $response_data['choices'][0]['message']['content'] ) {
			return $response_data['choices'][0]['message']['content'];
		}

		// Handle error
		return 'Error: Failed to retrieve response from the ChatGPT API';
	}

	

	
	
	
public function fetch_propmt() :void{
           global $wpdb;

    $prompt_id = $_POST['prompt_id'];
    $table_name = $wpdb->prefix . 'prompts_library';

    // Assuming $prompt_id is the ID, convert it to an integer for safety
    $prompt_id = intval($prompt_id);

    // Use a prepared statement to fetch the row based on the ID
    $query = $wpdb->prepare("SELECT * FROM $table_name WHERE id = %d", $prompt_id);
    $prompt_row = $wpdb->get_row($query);

    if ($prompt_row) {
        $prompt_text = $prompt_row->prompt_text; // Access the prompt_text property
        echo $prompt_text;
    } else {
        // Handle the case where no row was found with the given ID
        echo "Prompt not found";
    }
wp_die(); // 
	
	
	}

public function translate_process_row(): void  {
  global $wpdb;
    
    $prompt    = sanitize_text_field($_POST['prompt']);
    $post_id   = sanitize_text_field($_POST['post_id']);


    $post = get_post($post_id);

    if ($post) {
        $post_title = $post->post_title;
        $post_content = $post->post_content;
	}
	

       $title_prompt = "Translate the Woocommerce Product title according to given prompt and just translate, not make any change in title and title is given below: $post_title and prompt is $prompt"; // Separate prompt for content
       $title = $this->send_chatgpt_prompt($title_prompt,150);
	   
	   $content_prompts = "Translate the Woocommerce Product Description according to given prompt and just translate, not make any change in content, the content is '$post_content' and prompt is given below: $prompt"; // Separate prompt for content
       $content = $this->send_chatgpt_prompt($content_prompts,2000);
	   
	   	$short_description = wc_get_product( $post_id )->get_short_description();
        if (!empty($short_description)) {
         $shortdesc_prompts = "Translate the Woocommerce Product short Description according to given prompt and just translate it, not make any change in short Description, the short Description is '$short_description' and prompt is given below: $prompt"; // Separate prompt for content
        $shortdescription = $this->send_chatgpt_prompt($shortdesc_prompts,500);
         } else {
         $shortdescription = '';
         }
      
            $response_data = array(
                'title' => $title,
				'shortdescription' => $shortdescription,
                'content' => $content,
            );
            wp_send_json($response_data);
       

        // Don't forget to exit
        wp_die();


}

public function translate_process_row_php(): void {
	global $product;
    // Get data from the AJAX request
    $post_id = $_POST['post_id'];
    $post_title = $_POST['post_title'];
	$postshort = $_POST['postshort'];
   // echo $postshort_desc = 'dfvdvfggtf';
	$post_content = $_POST['post_content'];
    $action = $_POST['argument']; // Use 'action' instead of 'argument'

    // Create an array of post data to update
    $post_data = array(
        'ID' => $post_id, // Specify the post ID to update
        'post_title' => $post_title, // New post title
        'post_content' => $post_content, // New post content
        'post_status' => ($action === 'publish') ? 'publish' : 'draft', // Set post status based on action
    );

    // Update the post title and content
    $updated_post_id = wp_update_post($post_data, true);

    if (!is_wp_error($updated_post_id)) {
		$product = wc_get_product($post_id);
		$product->set_short_description($postshort);
        $product->save();
        // Post title and content updated successfully
        $new_permalink = get_permalink($updated_post_id);
        
        // No need to update post_name and guid; WordPress handles permalinks automatically
        
        $response = array(
            'status' => 'success',
            'message' => 'Post ' . ucfirst($action) . 'ed successfully!',
            'post_id' => $post_id,
			'postshort_desc' => $postshort,
			
        );
    } else {
        $error_message = $updated_post_id->get_error_message();
        $response = array(
            'status' => 'error',
            'message' => 'Failed to ' . $action . ' the post. Error: ' . $error_message,
        );
    }

    // Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
wp_die();
}

	

}

new CGPT_Product_translator();