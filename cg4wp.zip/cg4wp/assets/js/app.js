;(function ($) {

  let selectedProductIds = [];
  $('#cgptRewriteSubmitTrigger').css('pointer-events', 'none');

  function updateSubmitButtonState() {
    let anyCheckboxChecked = $('#titleCheckbox').is(':checked') || $('#descriptionCheckbox').is(':checked') || $('#shortDescriptionCheckbox').is(':checked');
    if (anyCheckboxChecked) {
      $('#cgptRewriteSubmitTrigger').css('pointer-events', 'auto');
    } else {
      $('#cgptRewriteSubmitTrigger').css('pointer-events', 'none');
    }
  }

  function updateRewriteActivityLog(message) {
    $('#cgptRewriteLogs').val($('#cgptRewriteLogs').val() + message + '\n');
  }

  $('#cgptRewriteTrigger').on('click', function (e) {
    e.preventDefault();
    $('#cgptRewriteModal').show();
    $('.cgpt-modal').addClass('cgpt-active');
  });

  $('#cgptReviewTrigger').on('click', function (e) {
    e.preventDefault();
    $('#cgptReviewModal').show();
    $('.cgpt-modal').addClass('cgpt-active');
  });

  $('.cgpt-close').on('click', function (e) {
    e.preventDefault();
    $(this).closest('.cgpt-modal').hide();
  });

  $('#titleCheckbox').on('change', function () {
    let isChecked = $('#titleCheckbox').is(':checked');
    $('#rewriteTitlePrompt').prop('disabled', !isChecked);
    updateSubmitButtonState();
  });

  $('#descriptionCheckbox').on('change', function () {
    let isChecked = $('#descriptionCheckbox').is(':checked');
    $('#rewriteDescriptionPrompt').prop('disabled', !isChecked);
    updateSubmitButtonState();
  });

  $('#shortDescriptionCheckbox').on('change', function () {
    let isChecked = $('#shortDescriptionCheckbox').is(':checked');
    $('#rewriteShortDescriptionPrompt').prop('disabled', !isChecked);
    updateSubmitButtonState();
  });

  $('#reviewCheckbox').on('change', function () {
    let isChecked = $('#reviewCheckbox').is(':checked');
    $('#cgptReviewPrompt').prop('disabled', !isChecked);
    updateSubmitButtonState();
  });

  $('#cgptRewriteTrigger').click(function (e) {
    e.preventDefault();
    let newDescription = $('.product-description-update-text').val();
    let selectedProducts = $('.check-column input[type="checkbox"]:checked');

    let dataArray = [];
    let productIdsArray = [];

    selectedProducts.each(function () {
      let productId = $(this).val();
      if (productId !== 'on') {
        productIdsArray.push(productId);
      }
    });

    selectedProductIds = productIdsArray;
    const selectedCount = selectedProductIds.length;
    if (selectedCount === 0) {
      $('.cgpt-selected-count').text('Please select products to continue');
      $('#cgptRewriteSubmitTrigger').css('pointer-events', 'none');
    } else {
      $('.cgpt-selected-count').text(selectedCount + ' products selected');
    }
  });

  $('#cgptRewriteSubmitTrigger').on('click', async function (e) {
    e.preventDefault();
    let titlePrompt = $('#rewriteTitlePrompt').val() ?? '';
    let descriptionPrompt = $('#rewriteDescriptionPrompt').val() ?? '';
    let shortDescriptionPrompt = $('#rewriteShortDescriptionPrompt').val() ?? '';

    updateRewriteActivityLog('Starting the Rewrite process.');

    for (const productId of selectedProductIds) {
      updateRewriteActivityLog('Rewrite process for product ID ' + productId + ' has been started...');

      try {
        if (titlePrompt) {
          await rewriteProductTitle(productId, titlePrompt);
        }
        if (descriptionPrompt) {
          await rewriteProductDescription(productId, descriptionPrompt);
        }
        if (shortDescriptionPrompt) {
          await rewriteProductShortDescription(productId, shortDescriptionPrompt);
        }

        updateRewriteActivityLog('Rewrite process for product ID ' + productId + ' has been completed.');
      } catch (error) {
        console.log('Error:', error);
      }
    }

    updateRewriteActivityLog('The Rewrite process for all of the selected products is completed successfully.');
  });

  function rewriteProductTitle(productId, titlePrompt) {
    return new Promise((resolve, reject) => {
      updateRewriteActivityLog('Starting to rewrite Title.');

      $.ajax({
        url: cgpt_posts.ajaxurl,
        type: 'POST',
        data: {
          action: 'request_cgpt_rewrite_title',
          product_id: productId,
          title: titlePrompt,
        },
        success: function (response) {
          const newTitle = response.title;
          updateRewriteActivityLog('The new title is: ' + newTitle);
          updateRewriteActivityLog('Title has been rewritten successfully.');
          resolve();
        },
        error: function (error) {
          console.log('Error:', error);
          reject(error);
        },
      });
    });
  }

  function rewriteProductDescription(productId, descriptionPrompt) {
    return new Promise((resolve, reject) => {
      updateRewriteActivityLog('Starting to rewrite Description.');

      $.ajax({
        url: cgpt_posts.ajaxurl,
        type: 'POST',
        data: {
          action: 'request_cgpt_rewrite_description',
          product_id: productId,
          description: descriptionPrompt,
        },
        success: function (response) {
          const newDescription = response.description;
          updateRewriteActivityLog('The new description is: ' + newDescription);
          updateRewriteActivityLog('Description has been rewritten successfully.');
          resolve();
        },
        error: function (error) {
          console.log('Error:', error);
          reject(error);
        },
      });
    });
  }

  function rewriteProductShortDescription(productId, shortDescriptionPrompt) {
    return new Promise((resolve, reject) => {
      updateRewriteActivityLog('Starting to rewrite short description.');

      $.ajax({
        url: cgpt_posts.ajaxurl,
        type: 'POST',
        data: {
          action: 'request_cgpt_rewrite_short_description',
          product_id: productId,
          short_description: shortDescriptionPrompt,
        },
        success: function (response) {
          const newShortDescription = response.short_description;
          updateRewriteActivityLog('The new short description is: ' + newShortDescription);
          updateRewriteActivityLog('Short description has been rewritten successfully.');
          resolve();
        },
        error: function (error) {
          console.log('Error:', error);
          reject(error);
        },
      });
    });
  }
  
//$('.chevron').addClass('down');

// Event delegation for .custom-dropdown-button click
$(document).on('click', '.custom-dropdown-button', function(e) {
    e.stopPropagation(); // Prevent event bubbling
    e.preventDefault(); // Prevent default behavior

    // Toggle the arrow class and show/hide the dropdown content
    $('.chevron').toggleClass('up down');
    $(this).siblings('.custom-dropdown-content').toggle();
});


$('#add-prompt-btn').click(function(e) {
		
        e.preventDefault();
        $('#prompt-popup').show(); // Show the popup
});




})
(jQuery);