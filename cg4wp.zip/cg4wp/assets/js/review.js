;(function ($) {

  let reviewTrigger = $('#cgptReviewTrigger');
  let checkbox = $('#reviewCheckbox');
  let textarea = $('#cgptReviewPrompt');
  let submitButton = $('#cgptReviewSubmitTrigger');
  let selectedProductIds = '';

  reviewTrigger.click(function (e) {
    e.preventDefault();
    let newDescription = $('.product-description-update-text').val();
    let selectedProducts = $('.check-column input[type="checkbox"]:checked');

    let dataArray = [];
    let productIdsArray = [];

    selectedProducts.each(function () {
      let productId = $(this).val();
      if (productId !== 'on') {
        productIdsArray.push(productId);
      }
    });

    selectedProductIds = productIdsArray;
    const selectedCount = selectedProductIds.length;
    if (selectedCount === 0) {
      $('.cgpt-selected-count').text('Please select products to continue');
      submitButton.css('pointer-events', 'none');
    } else {
      $('.cgpt-selected-count').text(selectedCount + ' products selected');
    }
  });

  checkbox.on('change', updateSubmitButtonState);
  textarea.on('input', updateSubmitButtonState);

  function updateSubmitButtonState() {
    if (checkbox.prop('checked') && textarea.val().trim() !== '' && selectedProductIds.length > 0) {
      submitButton.css('pointer-events', 'auto');
    } else {
      submitButton.css('pointer-events', 'none');
    }
  }

  function updateRewriteActivityLog(message) {
    $('#cgptReviewLogs').val($('#cgptReviewLogs').val() + message + '\n');
  }

  submitButton.on('click', async () => {
    await addProductReviews();
  });

  function addProductReviews() {
    let reviewCount = parseInt($('#cgptReviewCount').val());
    let reviewPrompt = $('#cgptReviewPrompt').val();

    selectedProductIds.forEach(async (productId) => {
      for (let i = 0; i < reviewCount; i++) {
        try {
          updateRewriteActivityLog('Review addition process started...');
          await new Promise((resolve) => {
            setTimeout(resolve, 20000);
          });

          await addReview(productId, reviewPrompt);

          updateRewriteActivityLog('Review addition process completed');
        } catch (error) {
          console.log('Error:', error);
        }

      }
    });
  }

  function addReview(productId, prompt) {
    return new Promise((resolve, reject) => {
      $.ajax({
        url: cgpt_reviews.ajaxurl,
        type: 'POST',
        data: {
          action: 'request_add_product_reviews',
          product_id: productId,
          prompt: prompt,
        },
        success: function (response) {
          const review = response.review;
          updateRewriteActivityLog('New review added: ' + review);
          resolve();
        },
        error: function (error) {
          console.log('Error:', error);
          reject(error);
        },
      });
    });
  }

})
(jQuery);
