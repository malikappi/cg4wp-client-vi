<?php
/**
 * Plugin Name: ChatGPT 4 WordPress
 * Description: A plugin that is used with WooCommerce and updates the product data with ChatGPT
 * Version: 1.0.0
 * Author: Amjad
 * Author URI: https://www.linkedin.com/in/muhammad-amjad-90400653/
 * Text Domain: chatgpt
 * Requires at least: 6.0
 * Requires PHP: 7.3
 */

defined( 'ABSPATH' ) || exit;

define( 'PLUGIN_DIR', __DIR__ );
define( 'PLUGIN_DIR_PATH', plugin_dir_url( __FILE__ ) );
define( 'PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'CHATGPT_SERVER_URL', 'https://chatgpt4wordpress.com/wp-json/chatgpt-server' );

// Activate the plugin
register_activation_hook( __FILE__, 'chatgpt_client_activate' );
function chatgpt_client_activate(): void {
	$site_url = get_site_url();
	$api_url  = CHATGPT_SERVER_URL . '/check-status';
	$response = wp_remote_post( $api_url, [
		'headers' => [
			'Content-Type' => 'application/json',
		],
		'body'    => json_encode( [ 'site_url' => $site_url ] ),
	] );

	if ( ! is_wp_error( $response ) && $response['response']['code'] === 200 ) {
		$body = json_decode( $response['body'], TRUE );
		if ( isset( $body['action'] ) && $body['action'] === 'approved' ) {
			update_option( 'chatgpt_client_activated', TRUE );
			
		} else {
			update_option( 'chatgpt_client_activated', FALSE );
		}
	}
}




// Include the activation check and settings page handling class
require_once PLUGIN_PATH . 'admin/class-activation.php';

