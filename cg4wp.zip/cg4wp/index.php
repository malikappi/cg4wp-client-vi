<?php
//Silence is Gold