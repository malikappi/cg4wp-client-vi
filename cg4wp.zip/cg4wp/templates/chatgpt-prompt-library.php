<?php
/**
 * Class: Settings -- API Key Form
 */

class Chatgpt_Setting_API_KEY {

	public function __construct() {
		
		
		add_action( 'wp_ajax_save_prompt_data', [
			$this,
			'save_prompt_data',
		] );
		
		add_action( 'wp_ajax_update_prompt', [
			$this,
			'update_prompt',
		] );
		
		add_action( 'wp_ajax_delete_selected_prompts', [
			$this,
			'delete_selected_prompts',
		] );
		
		
		
	}



function save_prompt_data() : void {
    global $wpdb;

    // Get form data from AJAX request
    $prompt_title = sanitize_text_field($_POST['prompt_title']);
    $prompt_category = sanitize_text_field($_POST['prompt_category']);
	$prompt_text = wp_unslash($_POST['prompt_text']);
	
	if($prompt_category == 1){$prompt_category = "Create Posts";}
	if($prompt_category == 2){$prompt_category = "Rewrite Posts";}
	if($prompt_category == 3){$prompt_category = "Comments Posts";}
	if($prompt_category == 4){$prompt_category = "Translate Posts";}
	if($prompt_category == 5){$prompt_category = "Rewrite Products";}
	if($prompt_category == 6){$prompt_category = "Reviews Products";}
	if($prompt_category == 7){$prompt_category = "Translate Products";}
	

    $current_user = wp_get_current_user();

    $auth = $current_user->user_login;
    


    // Insert data into the custom table
    $table_name = $wpdb->prefix . 'prompts_library';
    $insert_result = $wpdb->insert(
        $table_name,
        array(
            'prompt_title' => $prompt_title,
            'prompt_category' => $prompt_category,
            'prompt_text' => $prompt_text,
			'auth' => $auth,
        )
    );

    if ($insert_result) {
        // Data was inserted successfully
        $response = array(
            'success' => true,
            'data' => array(
                'prompt_title' => $prompt_title,
                'prompt_category' => $prompt_category,
				'prompt_auth' => $auth,
                'prompt_id' => $wpdb->insert_id, // Get the inserted ID
            ),
        );
    } else {
        // There was an error with the database insert
        $response = array(
            'success' => false,
            'message' => 'Error: Unable to save prompt data. Please try again later.',
        );
    }

    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);

    // Always exit to avoid extra output
    wp_die();
}


function update_prompt() : void {
    global $wpdb;

   $prompt_title = sanitize_text_field($_POST['promptTitle']);
$prompt_category = sanitize_text_field($_POST['promptCategory']);
$prompt_text = wp_unslash($_POST['promptText']);
$prompt_id = $_POST['promptId'];

if ($prompt_category == 1) {
    $prompt_category = "Create Posts";
} elseif ($prompt_category == 2) {
    $prompt_category = "Rewrite Posts";
} elseif ($prompt_category == 3) {
    $prompt_category = "Comments Posts";
} elseif ($prompt_category == 4) {
    $prompt_category = "Translate Posts";
} elseif ($prompt_category == 5) {
    $prompt_category = "Rewrite Products";
} elseif ($prompt_category == 6) {
    $prompt_category = "Reviews Products";
} elseif ($prompt_category == 7) {
    $prompt_category = "Translate Products";
}

$current_user = wp_get_current_user();
$auth = $current_user->user_login;

// Update data in the custom table
global $wpdb;
$table_name = $wpdb->prefix . 'prompts_library';

$data = array(
    'prompt_title' => $prompt_title,
    'prompt_category' => $prompt_category,
    'prompt_text' => $prompt_text,
    'auth' => $auth,
);

$where = array('ID' => $prompt_id);

$update_result = $wpdb->update($table_name, $data, $where);

    if ($update_result) {
        // Data was inserted successfully
        $response = array(
            'success' => true,
            'data' => array(
                'prompt_title' => $prompt_title,
                'prompt_category' => $prompt_category,
				'prompt_text' => $prompt_text,
				'prompt_auth' => $auth,
                'prompt_id' => $prompt_id, // Get the inserted ID
            ),
			 'message' => 'Prompt Updated Successfully.',
        );
    } else {
        // There was an error with the database insert
        $response = array(
            'success' => false,
            'message' => 'Error: Unable to save prompt data. Please try again later.',
        );
    }

    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);

    // Always exit to avoid extra output
    wp_die();
}


function delete_selected_prompts() : void{
    global $wpdb;

    $prompt_ids = $_POST['prompt_ids'];

    // Check if any IDs were provided
    if (!empty($prompt_ids)) {
        $table_name = $wpdb->prefix . 'prompts_library';

        // Delete selected records
        foreach ($prompt_ids as $prompt_id) {
            $wpdb->delete($table_name, array('id' => $prompt_id), array('%d'));
        }

        echo 'Selected prompts deleted successfully';
    } else {
        echo 'No prompts selected for deletion.';
    }

    // Always exit to avoid extra output
    wp_die();
}


}

new Chatgpt_Setting_API_KEY();