<?php

function chatgpt_create_posts() {
global $wpdb;	
          $plugin_dir = __DIR__;
         $image_url = plugin_dir_url( $plugin_dir ) . 'images/logo.png';
		 
$table_name = $wpdb->prefix . 'prompts_library'; // Replace with your table name
$query = "SELECT * FROM $table_name WHERE `prompt_category` LIKE 'Create Posts' ORDER BY `prompt_category` ASC ";
$prompts = $wpdb->get_results($query);
?>
			  <header>
		 
        <div class="logo">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
	<?php

?>

<div class="packagewrap" style="float:right">
<?php if(!get_option('chatgpt_product_name',false) == ''){?>
<div class="plandetail"><span style="color:#000;">Plan </span>: <?php echo get_option('chatgpt_product_name',false);?></div>
<?php } ?>

		 <div class="update-button">
            <a href="https://chatgpt4wordpress.com/pricing/">Upgrade Your Plan</a>
        </div>
	
	</div>
    </header>
	<main class="verfication" style="min-height:600px">
        <div class="api-form">
		
		
				
	
				<?php
				if ( ! empty( $messages ) ) {
					foreach ( $messages as $message ) {
						echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
					}
				}
				?>
				<div id="prompt">
				<div class="chatgpt-settings-page-heading">
					<h1>
						<?php echo __( 'Create Posts with ChatGPT', 'chatgpt' ); ?>
					</h1>
					
				</div>
    <div class="promt-cover">
<button class="add-prompt-btn" id="add-create-post-btn" style="background-color: #2C3EAB;">Publish</button><button class="draft-prompt-btn" id="draft-posts">Save as Draft</button></div>
        <div class="header">
            <span><strong>Keyword</strong></span>
            <span><strong>Choose Prompt</strong></span>
			<span><strong>Status</strong></span>
			<span><strong>View Post</strong></span>
           <span class="checkbox"><input type="checkbox" id="check-all"></span>
		   <span><strong>Remove</strong></span>
         </div>
      
	 <div id="post-wrap-container">
	 
	 
        <div id="post-wrap1" class="post-wrap">
		    <div class="data-row" id="post1">
            <span><input type="text" name="keyword[]" Placeholder="Keyword"> </span>
            <span>
			<select name="prompt[]" class="choose-promt">
			<option>Choose Prompt</option>
			<?php
// Check if there are prompts
if ($prompts) {
    // Loop through the prompts and do something with each prompt
    foreach ($prompts as $prompt) {
        $prompt_title = $prompt->prompt_title;
        $prompt_id = $prompt->id;	
		?>
         <option value="<?php echo $prompt_id;?>"><?php echo $prompt_title;?> </option>
      
	<?php
	    }
} else {
    // No prompts found
    echo "<option>No prompts found</option>";
}
?></select></span>
			 <span><div class="status">Not start</div></span>
			  <span><a href="" class="view-post" id="popup1">View Post</a> </span>
            <span class="checkbox"><td><input type="checkbox" class="record-checkbox" id="checkbox-1" value=""></td></span>
			<span class="deletrow" id="del1"><i class="fa fa-trash"  ></i></span>
        </div>
		
 <div class="popup-container" id="popup-container1" style="display: none;">
			<span class="close-popup w3-button w3-display-topright">&times;</span>
    <div class="popup-content">
   <form id="correct-the-post" method="POST">
   <h1>New Post Result </h1>
   <div class="yourkeyword">What was the keyword</div>
        <label>Post Title</label>
        <input type="text" id="prompt-title" name="post_title[]" class="post-title" required placeholder="Post Title">
<br><label>Content</label>
     <textarea name="post_text[]"  class="post_text" placeholder="Post Content"></textarea><br> 
        <button type="button" id="post-append" class="custom-dropdown-button">Update</button>
    </form>
	
    </div>
    
</div>
		
		</div>
	

	</div>
		
		
		 <button id="duplicateButton" class="duplicate-prompt-btn">Add New</button>
		  <button id="run-prompt-btn" class="run-prompt-btn">Run</button>
    </div>
 </div>
		</div>
		
<div id="plugin_activation_popup" style="display: none;">
  <span onclick="document.getElementById('plugin_activation_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		<h2 class="message" id="popupmessage"></h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Activate Plugin</a>
	</div>
</div>

<div id="eligible_popup" style="display: none;">
  <span onclick="document.getElementById('eligible_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		
			<h2 class="message" id="popupmessage"></h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Update/Activate</a>
	
	</div>
</div>

<?php echo get_option('chatgpt_license_key');?>
<?php echo get_option( 'chatgpt_api_key' );?>

	<script>
	
	
jQuery(document).ready(function ($) {
	
	 $('#run-prompt-btn').on('click', function () {

	
	  var shouldProceed = '<?php echo get_option( 'chatgpt_license_key' );?>'; 
	  
	if(shouldProceed == ''){
		$('#plugin_activation_popup #popupmessage').html('Please activate the plugin by using your license key,<br> Click below button');
		$('#plugin_activation_popup').show();
		return;
	}
	
		  var chatgpt_api_keys = '<?php echo get_option( 'chatgpt_api_key' );?>';
//alert(chatgpt_api_key);	
	if(chatgpt_api_keys == ''){
		$('#plugin_activation_popup #popupmessage').html('Please Validate the ChatGPT API key');
		$('#plugin_activation_popup').show();
		return;
	}
	
  // Get the total number of rows
    const totalRows = $('.data-row').length;
    let currentRow = 1;
	
    // Define a function to validate the current row
    function validateRow(rowNumber) {
        const keyword = $('#post' + rowNumber + ' input[name="keyword[]"]').val();
        const prompt = $('#post' + rowNumber + ' select.choose-promt').val();

        if (keyword.trim() === '' || prompt === 'Choose Prompt') {
            $('#post' + rowNumber + ' .status').html('<div class="waiting"></div>');
            return false; // Return false to indicate validation failure
        }
        return true; // Return true if validation passes
    }

    // Start by validating all rows
    let validationPassed = true;
    while (currentRow <= totalRows) {
        if (!validateRow(currentRow)) {
            validationPassed = false;
            break; // Stop validation and break out of the loop if any row fails validation
        }
        currentRow++;
    }

    if (validationPassed) {
		$.ajax({
            url: ajaxurl, // Adjust the URL to your needs
            type: 'POST',
            data: {
                action: 'eligibility_check',
				requestcount: totalRows,// This is the WordPress action to handle the request
            },
            success: function(response) {
				console.log(response);
				console.log(response.error_type);
				console.log(response.product_type);
				
        if(response.error_type === 'eligible' ){
			
			if(response.popup === 'show' ){
				 $('#eligible_popup').show();
				   $('#eligible_popup .message').text(response.message);
			}else{
				
				
		currentRow = 1; // Reset the current row counter
        processRow();
		
		$.ajax({
            url: ajaxurl, // Adjust the URL to your needs
            type: 'POST',
            data: {
                action: 'update_requests_counts',
				requestcount: totalRows,// This is the WordPress action to handle the request
            },
            success: function(response) {
				console.log(response);
			 },
            error: function (xhr, status, error) {
                console.log(error);
            }
        });	
			
				
				
				
				
				
			}
			
		
				
		 }else{
				   $('#eligible_popup').show();
				   $('#eligible_popup .message').text(response.message);
				   
				   
			   } // end of eligibilty check
			    
                
            }, ///end of succes control
			error: function (xhr, status, error) {
					console.log(Error);
                    //$('#post' + currentRow + ' .status').text('Error: ' + error);
                }
			
			
        });
		
		
		
    } else {
        alert('Please fill all the missing fields.');
		 return;
    }
   // Define a function to process the current row
    function processRow() {
        if (currentRow <= totalRows) {
            // Get data from the current row
            const keyword = $('#post' + currentRow + ' input[name="keyword[]"]').val();
            const prompt = $('#post' + currentRow + ' select.choose-promt').val();
            var nextpost = currentRow + 1;
            
            // Update the status to "Processing"
            $('#post' + currentRow + ' .status').html('<div class="processing">In Progress</div>');
            $('#post' + nextpost + ' .status').html('<div class="waiting"></div>');

            // Send an AJAX request to your PHP function
            $.ajax({
                url: ajaxurl, // Use WordPress AJAX URL
                type: 'POST',
                data: {
                    action: 'process_row', // PHP function to handle this action
                    keyword: keyword,
                    prompt: prompt
                },
                success: function (response) {
                   
                    
                    if (response.error) {
                        // Set an error message and change status to "Error"
                        $('#post' + currentRow + ' .status').text('Error: ' + response.error);
                    } else if (!response.title || !response.content) {
                        // Either title or content is missing, change status to "Error"
                        $('#post' + currentRow + ' .status').text('Error');
                    } else {
                        var output = '<form id="correct-the-post" method="POST"><h1>New Post Result </h1><div class="yourkeyword">Your keyword was "'+keyword+'"</div><label>Post Title</label><input type="text" class="post-title" value="'+response.title+'"name="post_title[]" required="" placeholder="Post Title"><br><label>Content</label><textarea name="post_text[]" class="post_text">"'+response.content+'"</textarea><br><button type="button" class="custom-dropdown-button">Update</button></form>';
                        
                        $('#popup-container' + currentRow + ' .popup-content').html(output);
                        $('#post' + currentRow + ' .status').html('<div class="completed"></div>');
                    }

                    // Move to the next row and process it
                    currentRow++;
                    processRow();
                },
                error: function (xhr, status, error) {
					console.log(Error);
                    $('#post' + currentRow + ' .status').text('Error: ' + error);
                }
            });
			
			$('.promt-cover').show();
			$('.post-wrap .view-post').css('display','block');
			$('.post-wrap .record-checkbox').show();
			$('#duplicateButton').hide();
			$('#run-prompt-btn').hide();
        }
    }

    // Start processing rows
    processRow();
});


	   let rowCounter = 1; // Initialize a row counter
	$('#duplicateButton').on('click', function () {
    // Clone the entire #post-wrap1 section, including the container
    const clonedPostWrap = $('#post-wrap1').clone();
    rowCounter++;

    const newPostWrapId = 'post-wrap' + rowCounter;
    const newPopupContainerId = 'popup-container' + rowCounter;

    clonedPostWrap.attr('id', newPostWrapId);
    //clonedPostWrap.removeClass('post-wrap');
    //clonedPostWrap.removeClass('post-wrap');

    // Update the IDs and classes of elements within the cloned section
    clonedPostWrap.find('.data-row').attr('id', 'post' + rowCounter);
    clonedPostWrap.find('a.view-post').attr('id', 'popup' + rowCounter);
    clonedPostWrap.find('input.record-checkbox').attr('id', 'checkbox-' + rowCounter);
    clonedPostWrap.find('input.record-checkbox').attr('value', rowCounter);
	clonedPostWrap.find('a.view-post').attr('id', 'popup' + rowCounter);
	clonedPostWrap.find('.deletrow').attr('id', 'del' + rowCounter);
    
    // Find the popup container and update its ID
    clonedPostWrap.find('.popup-container').attr('id', newPopupContainerId);
    
	// Clear the input fields and reset the select dropdown
    clonedPostWrap.find('input[name="keyword[]"]').val('');
    clonedPostWrap.find('select[name="prompt[]"]').val('Choose Prompt');
	
    // Append the cloned section to the container
    $('#post-wrap-container').append(clonedPostWrap);
    });

  

    // Event listener for the "Close" buttons
    $('#post-wrap-container').on('click', 'button.close-popup', function () {
        $(this).closest('.popup-container').hide();
    });


	 // Check All checkbox
    $('#check-all').change(function() {
        $('.record-checkbox').prop('checked', $(this).prop('checked'));
    });

    // Delete Selected button
    $('#delete-selected').click(function() {
        var selectedIds = [];

        // Loop through checked checkboxes and store their values (record IDs)
        $('.record-checkbox:checked').each(function() {
            selectedIds.push($(this).val());
        });

        if (selectedIds.length > 0) {
            // Send AJAX request to delete selected records
            $.ajax({
                type: 'POST',
                url: cgpt_posts.ajaxurl,
                data: {
                    action: 'delete_selected_prompts',
                    prompt_ids: selectedIds
                },
                success: function(response) {
                    // Handle the response (e.g., refresh the page)
                    alert(response);
                    location.reload();
                }
            });
        } else {
            alert('Please select at least one record to delete.');
        }
    });
	
	 $('#post-wrap-container').on('click', 'a.view-post', function (e) {
        e.preventDefault();

        // Extract the post ID from the link's ID
        const postId = $(this).attr('id').split('popup')[1];
		

        // Show the corresponding popup container
        $('#popup-container' + postId).show();
    });

    // Event listener for the "Close" buttons
    $('#post-wrap-container').on('click', 'span.close-popup', function () {
        $(this).closest('.popup-container').hide();
    });
	
	$('#post-wrap-container').on('click', '.custom-dropdown-button', function () {
        $(this).closest('.popup-container').hide();
    });


    $(document).on('click', '.deletrow', function () {
        //console.log('Clicked on .deletrow');

        // Get the parent data-row element
        var $row = $(this).closest('.data-row');

        // Extract the row ID from the ID attribute
        var rowId = $row.attr('id');
        console.log('Row ID:', rowId);

        // Extract the numeric value from the row ID
        var idNumber = parseInt(rowId.replace('post', ''), 10);
        console.log('idNumber:', idNumber);


$row.animate({
        marginLeft: '-100%', // Adjust the value as needed to control the animation
        opacity: 0
    }, 500, function() {
        // Remove the element from the DOM after the animation is complete
        $(this).remove();
    });


    });

 




	
// Define a variable to track the action (publish or draft)
let action = '';

// Event listener for the "Publish" button
$('#add-create-post-btn').on('click', function () {
	
    if ($('.record-checkbox:checked').length > 0) {
		
        postaction = 'publish';
        processRowsphp();
    } else {
        alert('Please check at least one post for the process');
    }
});

// Event listener for the "Save as Draft" button
$('#draft-posts').on('click', function () {
    if ($('.record-checkbox:checked').length > 0) {
        postaction = 'draft';
        processRowsphp();
    } else {
        alert('Please check at least one post for the process');
    }
});



// Function to process all rows
function processRowsphp() {
    // Get the total number of rows
    const total_rows = $('.data-row').length;

    // Initialize a variable to keep track of the current row

for (let currentRow = 1; currentRow <= total_rows; currentRow++) {
    const checkbox = $('#post' + currentRow + ' .record-checkbox');

    if (checkbox.is(':checked')) {
        // Get data from the current row
        const postTitle = $('#post-wrap' + currentRow + ' .post-title').val();
        const postContent = $('#post-wrap' + currentRow + ' .post_text').val();

        // Update the status based on the selected action
        if (postaction === 'publish') {
            $('#post' + currentRow + ' .status').text('Publishing');
        } else if (postaction === 'draft') {
            $('#post' + currentRow + ' .status').text('Saving as Draft');
        }

        $.ajax({
            url: cgpt_posts.ajaxurl,
            type: 'POST',
            data: {
                action: 'process_row_php', // PHP function to handle this action
                post_title: postTitle,
                post_content: postContent,
                argument: postaction // Send the selected action to PHP
            },
            success: function (response) {
                // Update the status based on the selected action
                if (postaction === 'publish') {
                    $('#post' + currentRow + ' .status').text('Published');
                } else if (postaction === 'draft') {
                    $('#post' + currentRow + ' .status').text('Draft Saved');
                }
            },
            error: function (xhr, status, error) {
                console.log(error);
            }
        });
    }
}




  }
  
  });

</script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style>
#prompt .header span {
    padding: 13px;
    font-size: 14px;
    line-height: 15px;
    
    display: block;
    float: left;
}

.promt-cover, .post-wrap a.view-post, .post-wrap .record-checkbox{display:none;}
#del1 i.fa.fa-trash {
    display: none;
}
.choose-promt{margin-top:10px;}
#prompt .header span:nth-child(1){width:28%;}
#prompt .header span:nth-child(2){width:28%;}
#prompt .header span:nth-child(3){width:10%;}
#prompt .header span:nth-child(4){width:6%;}
#prompt .header span:nth-child(5){width:6%;}
#prompt .header span:nth-child(6){width:6%;}

#prompt .data-row span:nth-child(1){width:28%;}
#prompt .data-row span:nth-child(2){width:28%;}
#prompt .data-row span:nth-child(3){width:10%;}
#prompt .data-row span:nth-child(4){width:6%;}
#prompt .data-row span:nth-child(5){width:6%;}
#prompt .data-row span:nth-child(6){width:6%;}
select.choose-promt {
    width: 97%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #f2f3fa;
    border-radius: 5px;
    color: #000;
    /* background: #f2f3fa; */
    /* appearance: revert; */
    height: 46px;
}
#wpfooter {
    display: none;
}
</style>
	
	<?php
}

function render_chatgpt_create_posts() {
    // Add the hidden plugin page with a non-existent parent menu slug
    add_submenu_page(
        'nonexistent-menu',
        'Create Posts',
        'Create Posts',
        'manage_options',
        'chatgpt_create_posts',
        'chatgpt_create_posts'
    );
}

// Hook the function to run during the admin_menu action
add_action('admin_menu', 'render_chatgpt_create_posts');

 ?>