<?php

function chatgpt_review_posts() {
	
          $plugin_dir = __DIR__;
         $image_url = plugin_dir_url( $plugin_dir ) . 'images/logo.png';
?>
			  <header>
		 
        <div class="logo">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
	<?php

?>
<div class="packagewrap" style="float:right">
<?php if(!get_option('chatgpt_product_name',false) == ''){?>
<div class="plandetail"><span style="color:#000;">Plan </span>: <?php echo get_option('chatgpt_product_name',false);?></div>
<?php } ?>

		 <div class="update-button">
            <a href="https://chatgpt4wordpress.com/pricing/">Upgrade Your Plan</a>
        </div>
	
	</div>
    </header>
	<main class="verfication" style="min-height:600px">
        <div class="api-form">
		
		
				
				<?php
				if ( ! empty( $messages ) ) {
					foreach ( $messages as $message ) {
						echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
					}
				}
				$selectedPostIds = isset($_GET['selected_post_ids']) ? explode(',', $_GET['selected_post_ids']) : array();
				
				if(isset($selectedPostIds)){$postcount = count($selectedPostIds);}else{$postcount = 0;}
?>
	<div id="rewrite_prompt" >
	<div class="chatgpt-settings-page-heading">
					<h1>
						<?php echo __( 'Create Comments for posts with ChatGPT', 'chatgpt' ); ?>
					</h1>
				</div>

	    <div class="promt-cover">
<button class="add-prompt-btn" id="add-create-post-btn" style="background-color: #2C3EAB;">Update</button><button class="draft-prompt-btn" id="draft-posts">Save as Draft</button></div>
	<div class="yourkeyword">You choose <?php echo $postcount;?> posts</div>

        <div class="header">
            <span><strong>Post Name</strong></span>
            <span><strong>Choose Prompt</strong></span>
			<span><strong>Status</strong></span>
			<span><strong>View Post</strong></span>
           <span class="checkbox"><input type="checkbox" id="check-all"></span>
         </div>
      
	 <div id="post-wrap-container">
	 
	 	<?php
	
	// Get the selected post IDs from the URL parameters
$selectedPostIds = isset($_GET['selected_post_ids']) ? explode(',', $_GET['selected_post_ids']) : array();

// Query posts using the selected post IDs
$args = array(
    'post_type' => 'post',
    'post__in' => $selectedPostIds,
    'posts_per_page' => -1,
);

$selectedPosts = new WP_Query($args);

// Loop through the selected posts and display them
if ($selectedPosts->have_posts()) :
$i = 1;
    while ($selectedPosts->have_posts()) : $selectedPosts->the_post();?>
        <div id="post-wrap<?php echo $i;?>" class="post-wrap">
		    <div class="data-row" id="post<?php echo $i;?>">
			<input type="hidden" value="<?php the_id();?>" name="post_id[]">
            <span><input type="text" value="<?php echo the_title();?>" name="post_title[]" Placeholder="Old Title"> </span>
            <span> <select name="prompt[]" id="prompt<?php echo $i;?>" class="choose-promt">
			<option>Prompt Name</option>
			<?php
			global $wpdb;
$table_name = $wpdb->prefix . 'prompts_library'; // Replace with your table name
$query = "SELECT * FROM $table_name WHERE `prompt_category` LIKE 'Comments Posts' ORDER BY `prompt_category` ASC ";
$prompts = $wpdb->get_results($query);
if ($prompts) {
    // Loop through the prompts and do something with each prompt
    foreach ($prompts as $prompt) {
        $prompt_title = $prompt->prompt_title;
        $prompt_id = $prompt->id;	
		?>
         <option value="<?php echo $prompt_id;?>"><?php echo $prompt_title;?> </option>
      
	<?php
	    }
} else {
    // No prompts found
    echo "<option>No prompts found</option>";
}
?></select></span>
		 </span>
			 <span><div class="status">Not start</div></span>
			  <span><a href="" class="view-post" id="popup<?php echo $i;?>">View Comment</a> </span>
            <span class="checkbox"><td><input type="checkbox" class="record-checkbox" value=""></td></span>
        </div>
		
<div class="popup-container" id="popup-container<?php echo $i;?>" style="display: none;">
			<span class="close-popup w3-button w3-display-topright">&times;</span>
    <div class="popup-content">
   <form id="correct-the-post" method="POST">
   <h1>New Post Result </h1>
   
        <label>Post Title</label>
        <input type="text" id="prompt-title" class="updated_title" value="<?php echo the_title();?>" name="post_title[]" required placeholder="Post Title">
<br><label>Comments</label>
     <textarea name="post_text[]"  class="post_text"></textarea><br> 
        <button type="button" id="post-append" class="custom-dropdown-button">Update</button>
    </form>
	
    </div>
    
</div>
		
		</div>
	
<?php 
$i++; 
    endwhile;
    wp_reset_postdata();
else :
    echo 'No posts found.';
endif;
?>	
<button id="run-prompt-btn" class="run-prompt-btn">Run</button>
	</div>
	
    </div>
 
		
		
			</div>
		</div>
		<div id="plugin_activation_popup" style="display: none;">
  <span onclick="document.getElementById('plugin_activation_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		<h2 class="message" id="popupmessage"></h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Activate Plugin</a>
	</div>
</div>

<div id="eligible_popup" style="display: none;">
  <span onclick="document.getElementById('eligible_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		<h2 class="message">Please activate the plugin by using your license key,<br> Click below button</h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Activate Plugin</a>
	</div>
</div>


<script>
jQuery(document).ready(function($) {
 
$('#run-prompt-btn').on('click', function () {
    var shouldProceed = '<?php echo get_option( 'chatgpt_license_key' );?>'; 
	if(shouldProceed == ''){
		$('#plugin_activation_popup #popupmessage').html('Please activate the plugin by using your license key,<br> Click below button');
		$('#plugin_activation_popup').show();
		return;
	}
	
	var chatgpt_api_key = '<?php echo get_option( 'chatgpt_api_key' );?>'; 
	if(chatgpt_api_key == ''){
		$('#plugin_activation_popup #popupmessage').html('Please Validate the ChatGPT API key');
		$('#plugin_activation_popup').show();
		return;
	}
   const promptype = $('#promptype').val();
        const prompt = $('#prompt-textarea').val();


        if ( promptype == 'Choose Type' || prompt == '') {
            alert('Prompt and Prompt Type are required');
            return;
        }
    // Get the total number of rows
    const totalRows = $('.data-row').length;

    // Initialize a variable to keep track of the current row
    let currentRow = 1;
    let errorOccurred = false; // Add an error flag

    // Define a function to process the current row
    function processRow() {
        if (currentRow <= totalRows && !errorOccurred) {
            // Get data from the current row
			const post_id = $('#post-wrap' + currentRow + ' input[name="post_id[]"]').val();
            const post_title = $('#post-wrap' + currentRow + ' input[name="post_title[]"]').val();
			const prompt = $('#post-wrap' + currentRow + ' select.choose-promt').val();
			console.log(post_title);
			console.log(prompt);
			
            var nextpost = currentRow + 1;
			 if (post_title.trim() === '' || prompt === 'Prompt Name') {
                $('#post-wrap' + currentRow + ' .status').text('Validation error');
                //$('.status').text('Stop');
                errorOccurred = true; // Set error flag
                return; // Stop processing this row
            }
            // Update the status to "Processing"
            $('#post-wrap' + currentRow + ' .status').html('<div class="processing">In Progress</div>');
            $('#post-wrap' + nextpost + ' .status').html('<div class="waiting"></div>');

            // Send an AJAX request to your PHP function
            $.ajax({
                url: ajaxurl, // Use WordPress AJAX URL
                type: 'POST',
                data: {
                    action: 'request_add_post_reviews', // PHP function to handle this action
                    post_title: post_title,
                    prompt: prompt,
					post_id : post_id
                    
                },
                success: function (response) {
				$('#post-wrap' + currentRow + ' a.view-post').css('display','block');
				$('#post-wrap' + currentRow + ' .record-checkbox').css('display','inline-block');
                    
                   $('#popup-container' + currentRow + ' .popup-content .updated_title').val(response.title);
                   $('#popup-container' + currentRow + ' .popup-content .post_text').val(response.comments);
                  $('#post-wrap' + currentRow + ' .status').html('<div class="completed"></div>');

                    // Move to the next row and process it
                    currentRow++;
                    processRow();
                },
                error: function (xhr, status, error) {
					//alert(error);
                    $('#post' + currentRow + ' .status').text('Error: ' + error);
					$('.status').text('Stop');
                    errorOccurred = true; // Set error flag
                }
				
			
			
			
            });
			$('.promt-cover').show();
			$('#run-prompt-btn').hide();
        }
    }

  $.ajax({
            url: ajaxurl, // Adjust the URL to your needs
            type: 'POST',
            data: {
                action: 'eligibility_check',
				requestcount: totalRows,// This is the WordPress action to handle the request
            },
            success: function(response) {
				
				
        if(response.error_type === 'eligible' ){
			
			if(response.popup === 'show' ){
				 $('#eligible_popup').show();
				   $('#eligible_popup .message').text(response.message);
			}else{
				
				
		currentRow = 1; // Reset the current row counter
        processRow();
		
		$.ajax({
            url: ajaxurl, // Adjust the URL to your needs
            type: 'POST',
            data: {
                action: 'update_requests_counts',
				requestcount: totalRows,// This is the WordPress action to handle the request
            },
            success: function(response) {
				console.log(response);
			 },
            error: function (xhr, status, error) {
                console.log(error);
            }
        });	
			
				}
			
		
				
		 }else{
				   $('#eligible_popup').show();
				   $('#eligible_popup .message').text(response.message);
				   
				   
			   } // end of eligibilty check
			    
                
            }, ///end of succes control
			error: function (xhr, status, error) {
					console.log(Error);
                    //$('#post' + currentRow + ' .status').text('Error: ' + error);
                }
			
			
        });
			
		
});

	
 $('#post-wrap-container').on('click', 'a.view-post', function (e) {
        e.preventDefault();

        // Extract the post ID from the link's ID
        const postId = $(this).attr('id').split('popup')[1];
		

        // Show the corresponding popup container
        $('#popup-container' + postId).show();
    });

    // Event listener for the "Close" buttons
    $('#post-wrap-container').on('click', 'span.close-popup', function () {
        $(this).closest('.popup-container').hide();
    });
	
	$('#post-wrap-container').on('click', '.custom-dropdown-button', function () {
        $(this).closest('.popup-container').hide();
    });

// Define a variable to track the action (publish or draft)
	
// Define a variable to track the action (publish or draft)
let action = '';

// Event listener for the "Publish" button
$('#add-create-post-btn').on('click', function () {
	
    if ($('.record-checkbox:checked').length > 0) {
		
        postaction = 'publish';
        processRowsphp();
    } else {
        alert('Please check at least one post for the process');
    }
});

// Event listener for the "Save as Draft" button
$('#draft-posts').on('click', function () {
    if ($('.record-checkbox:checked').length > 0) {
        postaction = 'draft';
        processRowsphp();
    } else {
        alert('Please check at least one post for the process');
    }
});
// Function to process all rows
function processRowsphp() {
    // Get the total number of rows
    const total_rows = $('.data-row').length;

    // Initialize a variable to keep track of the current row

for (let currentRow = 1; currentRow <= total_rows; currentRow++) {
    const checkbox = $('#post' + currentRow + ' .record-checkbox');

    if (checkbox.is(':checked')) {
           

const comments = $('#post-wrap' + currentRow + ' .post_text').val();
 const post_id =$('#post-wrap' + currentRow + ' input[name="post_id[]"]').val();
//console.log(postTitle); // Corrected 'console.log'

            // Update the status based on the selected action
            if (postaction === 'publish') {
                $('#post' + currentRow + ' .status').text('Publishing');
            } else if (postaction === 'draft') {
                $('#post' + currentRow + ' .status').text('Saving as Draft');
            }

          
            $.ajax({
                 url: cgpt_posts.ajaxurl,
                type: 'POST',
                data: {
                    action: 'rewrite_process_row_comments', // PHP function to handle this action
                    post_id: post_id,
                    comments: comments,
					argument: postaction // Send the selected action to PHP
                },
				
                success: function (response) {
					
                    // Update the status based on the selected action
                    if (postaction === 'publish') {
                        $('#post' + currentRow + ' .status').text('Published');
                    } else if (postaction === 'draft') {
                        $('#post' + currentRow + ' .status').text('Draft Saved');
                    }

                    // Move to the next row and process it
                    currentRow++;
                    processRowphp();
                },
                error: function (xhr, status, error) {
                    console.log(error);
                }
            });
      


	  }
}




  }

 // Check All checkbox
    $('#check-all').change(function() {
        $('.record-checkbox').prop('checked', $(this).prop('checked'));
    });
	
	
});

</script>

<style>
#wpfooter{display:none}
form#rewrite-the-post {
    float: left;
    width: 63%;
}</style>
<style>
#rewrite_prompt .header span {
    padding: 13px;
    font-size: 14px;
    line-height: 15px;
    
    display: block;
    float: left;
}
.promt-cover, .post-wrap a.view-post, .post-wrap .record-checkbox{display:none;}
#del1 i.fa.fa-trash {
    display: none;
}
.choose-promt{margin-top:10px;}
#rewrite_prompt .header span:nth-child(1){width:30%;}
#rewrite_prompt .header span:nth-child(2){width:30%;}
#rewrite_prompt .header span:nth-child(3){width:10%;}
#rewrite_prompt .header span:nth-child(4){width:6%;}
#rewrite_prompt .header span:nth-child(5){width:10%;}
#rewrite_prompt .header span:nth-child(6){width:6%;}

#rewrite_prompt .data-row span:nth-child(1){width:30%;}
#rewrite_prompt .data-row span:nth-child(2){width:30%;}
#rewrite_prompt .data-row span:nth-child(3){width:30%;}
#rewrite_prompt .data-row span:nth-child(4){width:10%;}
#rewrite_prompt .data-row span:nth-child(5){width:10%;}
#rewrite_prompt .data-row span:nth-child(6){width:6%;}
select.choose-promt {
    width: 97%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #f2f3fa;
    border-radius: 5px;
    /* color: #006091; */
    /* background: #f2f3fa; */
    /* appearance: revert; */
    height: 45px;
    margin-bottom: 0px !important;
}
#wpfooter {
    display: none;
}
</style>
<?php
}

function render_chatgpt_review_posts() {
    // Add the hidden plugin page with a non-existent parent menu slug
    add_submenu_page(
        'nonexistent-menu',
        'Review Posts',
        'Review Posts',
        'manage_options',
        'chatgpt_review_posts',
        'chatgpt_review_posts'
    );
}

// Hook the function to run during the admin_menu action
add_action('admin_menu', 'render_chatgpt_review_posts');

 ?>
