<?php

function chatgpt_translate_posts() {
	
          $plugin_dir = __DIR__;
         $image_url = plugin_dir_url( $plugin_dir ) . 'images/logo.png';
?>
		  <header>
		 
        <div class="logo">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
	<?php

?>
<div class="packagewrap" style="float:right">
<?php if(!get_option('chatgpt_product_name',false) == ''){?>
<div class="plandetail"><span style="color:#000;">Plan </span>: <?php echo get_option('chatgpt_product_name',false);?></div>
<?php } ?>

		 <div class="update-button">
            <a href="https://chatgpt4wordpress.com/pricing/">Upgrade Your Plan</a>
        </div>
	
	</div>
    </header>
	<main class="verfication" style="min-height:600px">
        <div class="api-form">
		
		
				

				<?php
				if ( ! empty( $messages ) ) {
					foreach ( $messages as $message ) {
						echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
					}
				}
				$selectedPostIds = isset($_GET['selected_post_ids']) ? explode(',', $_GET['selected_post_ids']) : array();
				
				if(isset($selectedPostIds)){$postcount = count($selectedPostIds);}else{$postcount = 0;}

				?>
<form id="rewrite-the-post" method="POST">
<div class="chatgpt-settings-page-heading" style="width:100%">
					<h1>
						<?php echo __( 'Translate Posts Unsing ChatGpt', 'chatgpt' ); ?>
					</h1>
				</div>
 <div class="yourkeyword">You choose <?php echo $postcount;?> posts</div>
      <div class="cg-row">
	  
	  
		<div class="col5">
	  <label>Choose Prompt</label>
       <select name="prompt" id="prompt" class="choose-promt">
			<option>Prompt Name</option>
			<?php
			global $wpdb;
$table_name = $wpdb->prefix . 'prompts_library'; // Replace with your table name
$query = "SELECT * FROM $table_name WHERE `prompt_category` LIKE 'Translate Posts' ORDER BY `prompt_category` ASC ";
$prompts = $wpdb->get_results($query);
if ($prompts) {
    // Loop through the prompts and do something with each prompt
    foreach ($prompts as $prompt) {
        $prompt_title = $prompt->prompt_title;
        $prompt_id = $prompt->id;	
		?>
         <option value="<?php echo $prompt_id;?>"><?php echo $prompt_title;?> </option>
      
	<?php
	    }
} else {
    // No prompts found
    echo "<option>No prompts found</option>";
}
?></select></span>
			
		</div>
		</div>
	
    <div class="cg-row">
         <label>View Edit Prompt</label>
     <textarea name="promt" id="prompt-textarea" class="post_text" placeholder="Prompt Text"></textarea><br> 
        <button type="button" id="rewrite_run" class="custom-dropdown-button">Run</button>
		</div>
  	
		
		
  

  </form>



				<div id="rewrite_prompt" style="display:none">
				<div class="chatgpt-settings-page-heading">
					<h1>
						<?php echo __( 'Translate Posts Unsing ChatGpt', 'chatgpt' ); ?>
					</h1>
				</div>
    <div class="promt-cover">
<button class="add-prompt-btn" id="add-create-post-btn" style="background-color: #2C3EAB;">Update</button><button class="draft-prompt-btn" id="draft-posts">Save as Draft</button></div>
        <div class="header">
            <span><strong>Current Post</strong></span>
            <span><strong>New Post</strong></span>
			<span><strong>Status</strong></span>
			<span><strong>View Post</strong></span>
           <span class="checkbox"><input type="checkbox" id="check-all"></span>
         </div>
      
	 <div id="post-wrap-container">
	 
	 	<?php
	
	// Get the selected post IDs from the URL parameters
$selectedPostIds = isset($_GET['selected_post_ids']) ? explode(',', $_GET['selected_post_ids']) : array();

// Query posts using the selected post IDs
$args = array(
    'post_type' => 'post',
    'post__in' => $selectedPostIds,
    'posts_per_page' => -1,
);

$selectedPosts = new WP_Query($args);

// Loop through the selected posts and display them
if ($selectedPosts->have_posts()) :
$i = 1;
    while ($selectedPosts->have_posts()) : $selectedPosts->the_post();?>
        <div id="post-wrap<?php echo $i;?>" class="post-wrap">
		    <div class="data-row" id="post<?php echo $i;?>">
			<input type="hidden" value="<?php the_id();?>" name="post_id[]">
            <span><input type="text" value="<?php echo the_title();?>" name="old_title[]" Placeholder="Old Title"> </span>
            <span><input type="text" name="new_title[]" Placeholder="New Title"> </span>
			 <span><div class="status">Not start</div></span>
			  <span><a href="" class="view-post" id="popup<?php echo $i;?>">View Post</a> </span>
            <span class="checkbox"><td><input type="checkbox" class="record-checkbox" value=""></td></span>
        </div>
		
<div class="popup-container" id="popup-container<?php echo $i;?>" style="display: none;">
			<span class="close-popup w3-button w3-display-topright">&times;</span>
    <div class="popup-content">
   <form id="correct-the-post" method="POST">
   <h1>Translated Post Result </h1>
   
        <label>Post Title</label>
        <input type="text" id="prompt-title" class="updated_title" value="<?php echo the_title();?>" name="post_title[]" required placeholder="Post Title">
<br><label>Content</label>
     <textarea name="post_text[]"  class="post_text"><?php echo the_content();?></textarea><br> 
        <button type="button" id="post-append" class="custom-dropdown-button">Update</button>
    </form>
	
    </div>
    
</div>
		
		</div>
	
<?php 
$i++; 
    endwhile;
    wp_reset_postdata();
else :
    echo 'No posts found.';
endif;
?>	
	</div>
	
    </div>
 
		
			</div>
		</div>
		<div id="plugin_activation_popup" style="display: none;">
  <span onclick="document.getElementById('plugin_activation_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		<h2>Please activate the plugin by using your license key,<br> Click below button</h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Activate Plugin</a>
	</div>
</div>

<div id="eligible_popup" style="display: none;">
  <span onclick="document.getElementById('eligible_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		<h2 class="message">Please activate the plugin by using your license key,<br> Click below button</h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Activate Plugin</a>
	</div>
</div>

<script>
jQuery(document).ready(function($) {
 
$('#rewrite_run').on('click', function () {
	
	var shouldProceed = '<?php echo get_option( 'chatgpt_client_activated' );?>'; 
	if(shouldProceed == ''){
		$('#plugin_activation_popup').show();
		return;
	}
	const promptselect = $('#prompt').val();
    const prompttextarea = $('#prompt-textarea').val();
	
    if (promptselect == 'Prompt Name' || prompttextarea === '') {
    alert('Prompt and Prompt Type are required');
    return;
     }
    $('#rewrite-the-post').hide();
    $('#rewrite_prompt').show();
    
    const prompt = $('#prompt-textarea').val();
    // Get the total number of rows
    const totalRows = $('.data-row').length;

    // Initialize a variable to keep track of the current row
    let currentRow = 1;
    let errorOccurred = false; // Add an error flag

    // Define a function to process the current row
    function processRow() {
        if (currentRow <= totalRows && !errorOccurred) {
            // Get data from the current row
            const post_id = $('#post-wrap' + currentRow + ' input[name="post_id[]"]').val();
            var nextpost = currentRow + 1;
			
            // Update the status to "Processing"
            $('#post-wrap' + currentRow + ' .status').html('<div class="processing">In Progress</div>');
            $('#post-wrap' + nextpost + ' .status').html('<div class="waiting"></div>');

            // Send an AJAX request to your PHP function
            $.ajax({
                url: ajaxurl, // Use WordPress AJAX URL
                type: 'POST',
                data: {
                    action: 'translate_post_data', // PHP function to handle this action
                    prompt: prompt,
                    post_id: post_id
                },
                success: function (response) {
					 $('#post-wrap' + currentRow + ' a.view-post').css('display','block');
					 $('#post-wrap' + currentRow + ' .record-checkbox').css('display','inline-block');
                    $('#post-wrap' + currentRow + ' input[name="new_title[]"]').val(response.title);
                    $('#popup-container' + currentRow + ' .popup-content .updated_title').val(response.title);
                    $('#popup-container' + currentRow + ' .popup-content .post_text').val(response.content);
                    $('#post-wrap' + currentRow + ' .status').html('<div class="completed"></div>');

                    // Move to the next row and process it
                    currentRow++;
                    processRow();
                },
                error: function (xhr, status, error) {
					console.log(error);
                    $('#post' + currentRow + ' .status').text('Error: ' + error);
					$('.status').text('Stop');
                    errorOccurred = true; // Set error flag
                }
            });
			
			$('.promt-cover').show();
			$('#run-prompt-btn').hide();
        }
		
    }

   $.ajax({
            url: ajaxurl, // Adjust the URL to your needs
            type: 'POST',
            data: {
                action: 'eligibility_check',
				requestcount: totalRows,// This is the WordPress action to handle the request
            },
            success: function(response) {
				
				
        if(response.error_type === 'eligible' ){
			
			if(response.popup === 'show' ){
				 $('#eligible_popup').show();
				   $('#eligible_popup .message').text(response.message);
			}else{
				
				
		currentRow = 1; // Reset the current row counter
        processRow();
		
		$.ajax({
            url: ajaxurl, // Adjust the URL to your needs
            type: 'POST',
            data: {
                action: 'update_requests_counts',
				requestcount: totalRows,// This is the WordPress action to handle the request
            },
            success: function(response) {
				console.log(response);
			 },
            error: function (xhr, status, error) {
                console.log(error);
            }
        });	
				
			}
			
		
				
		 }else{
				   $('#eligible_popup').show();
				   $('#eligible_popup .message').text(response.message);
				   
				   
			   } // end of eligibilty check
			    
                
            }, ///end of succes control
			error: function (xhr, status, error) {
					console.log(Error);
                    //$('#post' + currentRow + ' .status').text('Error: ' + error);
                }
			
			
        });
		
	
});

	

 
 
  $(document).on('change', '#prompt', function() {
        const selectedPromptId = $(this).val();

        $.ajax({
            type: 'POST',
            url: ajaxurl, // Use WordPress AJAX URL
            data: {
                action: 'fetch_propmt',
                prompt_id: selectedPromptId
            },
            success: function(response) {
                $('#prompt-textarea').val(response);
            },
            error: function(xhr, status, error) {
                console.log(error);
            }
        });
    });
	
	

    // Event listener for the "Close" buttons
    $('#post-wrap-container').on('click', 'button.close-popup', function () {
        $(this).closest('.popup-container').hide();
    });


	 // Check All checkbox
    $('#check-all').change(function() {
        $('.record-checkbox').prop('checked', $(this).prop('checked'));
    });

 
	 $('#post-wrap-container').on('click', 'a.view-post', function (e) {
        e.preventDefault();

        // Extract the post ID from the link's ID
        const postId = $(this).attr('id').split('popup')[1];
		

        // Show the corresponding popup container
        $('#popup-container' + postId).show();
    });

    // Event listener for the "Close" buttons
    $('#post-wrap-container').on('click', 'span.close-popup', function () {
        $(this).closest('.popup-container').hide();
    });
	
	$('#post-wrap-container').on('click', '.custom-dropdown-button', function () {
        $(this).closest('.popup-container').hide();
    });



 
	
	
// Define a variable to track the action (publish or draft)
let action = '';

// Event listener for the "Publish" button
$('#add-create-post-btn').on('click', function () {
	
    if ($('.record-checkbox:checked').length > 0) {
		
        postaction = 'publish';
        processRowsphp();
    } else {
        alert('Please check at least one post for the process');
    }
});

// Event listener for the "Save as Draft" button
$('#draft-posts').on('click', function () {
    if ($('.record-checkbox:checked').length > 0) {
        postaction = 'draft';
        processRowsphp();
    } else {
        alert('Please check at least one post for the process');
    }
});

function processRowsphp() {
    // Get the total number of rows
    const total_rows = $('.data-row').length;

    // Initialize a variable to keep track of the current row

for (let currentRow = 1; currentRow <= total_rows; currentRow++) {
    const checkbox = $('#post' + currentRow + ' .record-checkbox');

    if (checkbox.is(':checked')) {
           
const postTitle = $('#post-wrap' + currentRow + ' .updated_title').val();
const postContent = $('#post-wrap' + currentRow + ' .post_text').val();
 const post_id =$('#post-wrap' + currentRow + ' input[name="post_id[]"]').val();
//console.log(postTitle); // Corrected 'console.log'

            // Update the status based on the selected action
            if (postaction === 'publish') {
                $('#post' + currentRow + ' .status').text('Publishing');
            } else if (postaction === 'draft') {
                $('#post' + currentRow + ' .status').text('Saving as Draft');
            }

          
            $.ajax({
                 url: cgpt_posts.ajaxurl,
                type: 'POST',
                data: {
                    action: 'translate_post_save_php', // PHP function to handle this action
                    post_title: postTitle,
                    post_content: postContent,
					post_id: post_id,
                    argument: postaction // Send the selected action to PHP
                },
				
                success: function (response) {
					
                    // Update the status based on the selected action
                    if (postaction === 'publish') {
                        $('#post' + currentRow + ' .status').text('Published');
                    } else if (postaction === 'draft') {
                        $('#post' + currentRow + ' .status').text('Draft Saved');
                    }

                    // Move to the next row and process it
                    currentRow++;
                    processRowphp();
                },
                error: function (xhr, status, error) {
                    console.log(error);
                }
            });
      
     }
   }
}

	
	
});

</script>

<style>
#wpfooter{display:none}
form#rewrite-the-post {
    float: left;
    width: 63%;
}
#rewrite_prompt .header span {
    padding: 13px;
    font-size: 14px;
    line-height: 15px;
    
    display: block;
    float: left;
}
.promt-cover, .post-wrap a.view-post, .post-wrap .record-checkbox{display:none;}
#del1 i.fa.fa-trash {
    display: none;
}
.choose-promt{margin-top:10px;}
#rewrite_prompt .header span:nth-child(1){width:33%;}
#rewrite_prompt .header span:nth-child(2){width:33%;}
#rewrite_prompt .header span:nth-child(3){width:10%;}
#rewrite_prompt .header span:nth-child(4){width:6%;}
#rewrite_prompt .header span:nth-child(5){width:5%;}
#rewrite_prompt .header span:nth-child(6){width:6%;}

#rewrite_prompt .data-row span:nth-child(1){width:33%;}
#rewrite_prompt .data-row span:nth-child(2){width:33%;}
#rewrite_prompt .data-row span:nth-child(3){width:33%;}
#rewrite_prompt .data-row span:nth-child(4){width:10%;}
#rewrite_prompt .data-row span:nth-child(5){width:6%;}
#rewrite_prompt .data-row span:nth-child(6){width:5%;}
select.choose-promt {
    width: 97%;
    padding: 8px;
    margin-top: 5px;
    border: 1px solid #f2f3fa;
    border-radius: 5px;
    /* color: #006091; */
    /* background: #f2f3fa; */
    /* appearance: revert; */
    height: 45px;
    margin-bottom: 0px !important;
}
#wpfooter {
    display: none;
}
</style>
	<?php
}

function render_chatgpt_translate_posts() {
    // Add the hidden plugin page with a non-existent parent menu slug
    add_submenu_page(
        'nonexistent-menu',
        'Re-write Posts',
        'Re-write Posts',
        'manage_options',
        'chatgpt_translate_posts',
        'chatgpt_translate_posts'
    );
}

// Hook the function to run during the admin_menu action
add_action('admin_menu', 'render_chatgpt_translate_posts');

 ?>
