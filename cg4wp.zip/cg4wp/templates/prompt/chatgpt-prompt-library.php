	
		<?php
		$plugin_dir = __DIR__;
         $image_url = plugin_dir_url( $plugin_dir ) . 'images/logo.png';
		 ?> 
      
	
			  <header>
		 
        <div class="logo">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
	<?php

?>
<div class="packagewrap" style="float:right">
<?php if(!get_option('chatgpt_product_name',false) == ''){?>
<div class="plandetail"><span style="color:#000;">Plan </span>: <?php echo get_option('chatgpt_product_name',false);?></div>
<?php } ?>

		 <div class="update-button">
            <a href="https://chatgpt4wordpress.com/pricing/">Upgrade Your Plan</a>
        </div>
	
	</div>
    </header>
	<main class="verfication" style="min-height:600px">
        <div class="api-form">
		<div id="delete-response"></div>
		
				<div class="chatgpt-settings-page-heading">
					<h1>
						<?php echo __( 'Prompt List ', 'chatgpt' ); ?>
					</h1>
					
				</div>
				<?php
global $wpdb;
$table_name = $wpdb->prefix . 'prompts_library ORDER BY id DESC'; // Replace with your table name
$query = "SELECT * FROM $table_name";
$prompts = $wpdb->get_results($query);

$countquery = "SELECT COUNT(*) FROM $table_name";
$total_count = $wpdb->get_var($countquery);?>

<div class="promt-cover">
<div class="prompt-count">You have <?php echo $total_count;?> prompts </div><button class="add-prompt-btn" id="add-prompt">Add Prompt</button><button class="delete-prompt-btn" id="delete-selected">Delete Prompt</button></div>
				<?php
				if ( ! empty( $messages ) ) {
					foreach ( $messages as $message ) {
						echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
					}
				}
				?>
				<div id="prompt">
    
        <div class="header">
            <span><strong>Prompt Name</strong></span>
            <span><strong>Category</strong></span>
			<span><strong>View</strong></span>
			<span><strong>Author</strong></span>
           <span class="checkbox"><input type="checkbox" id="check-all"></span>
         </div>

<?php
// Check if there are prompts
if ($prompts) {
    // Loop through the prompts and do something with each prompt
    foreach ($prompts as $prompt) {
        $prompt_title = $prompt->prompt_title;
        $prompt_category = $prompt->prompt_category;
       $auth = $prompt->auth;		
		?>
         <div class="data-row" id="row<?php echo $prompt->id;?>">
            <span><?php echo $prompt_title;?> </span>
            <span><?php echo $prompt_category;?></span>
			<span><a class="view-post" id="popup<?php echo $prompt->id;?>">View Post</a> </span>
			<span><?php echo $auth;?></span>
            <span class="checkbox">
			<?php if (!($auth == "system")) {?>
			<input type="checkbox" class="record-checkbox" value="<?php echo $prompt->id; ?>">
			<?php }?>
			</span>
			</div>
	<?php
	    }
} else {
    // No prompts found
    echo "No prompts found in the database.";
}
?>	
		
    </div>


			
			</div>
		</div>
		

<?php
// Check if there are prompts
if ($prompts) {
    // Loop through the prompts and do something with each prompt
    foreach ($prompts as $prompt) {
		 $prompt_id = $prompt->id;
     $prompt_title = $prompt->prompt_title;
     $prompt_category_text = $prompt->prompt_category;
	 $prompt_text = $prompt->prompt_text;
     $auth = $prompt->auth;	
    if($prompt_category_text == "Create Posts"){$prompt_category = 1;}
	if($prompt_category_text == "Rewrite Posts"){$prompt_category = 2;}
	if($prompt_category_text == "Comments Posts"){$prompt_category = 3;}
	if($prompt_category_text == "Translate Posts"){$prompt_category = 4;}
	if($prompt_category_text == "Rewrite Products"){$prompt_category = 5;}
	if($prompt_category_text == "Reviews Products"){$prompt_category = 6;}
	if($prompt_category_text == "Translate Product"){$prompt_category = 7;}	   
		?>
		
	<?php if (!($auth == "system")) {?>
			
			<div class="popup-container" id="popup-container<?php echo $prompt->id;?>" style="display: none;">
			  <span onclick="document.getElementById('popup-container<?php echo $prompt->id;?>').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
    <h2>Add New Prompt</h2>
	<div id="response"></div>
    <form id="prompt-form" method="POST">
        
        <input type="text" id="prompt-title" value="<?php echo $prompt->prompt_title;?>" name="prompt_title" required placeholder="Prompt Title">
<br><input type="hidden" name="id" value="<?php echo $prompt_id;?>">
        <label for="prompt-category">Prompt Category </label>
        <select id="prompt-category" name="prompt_category">
		    <option value="" selected>Choose Category</option>
            <option value="1" <?php if($prompt_category == 1){echo "selected";}?>>Create Posts</option>
            <option value="2" <?php if($prompt_category == 2){echo "selected";}?>>Rewrite Posts</option>
			<option value="3" <?php if($prompt_category == 3){echo "selected";}?>>Comments Posts</option>
			<option value="4" <?php if($prompt_category == 4){echo "selected";}?>>Translate Posts</option>
			<option value="5" <?php if($prompt_category == 5){echo "selected";}?>>Rewrite Products</option>
			<option value="6" <?php if($prompt_category == 6){echo "selected";}?>>Reviews Products</option>
			<option value="7" <?php if($prompt_category == 7){echo "selected";}?>>Translate Product</option>
            <!-- Add more options as needed -->
        </select>
		<br><br>
	<label>Prompt</label>
     <textarea name="prompt_text" id="prompt_text" placeholder="Text"><?php echo $prompt_text;?></textarea><br> 
       <button type="submit" id="updateprompt" data-popupid="popup-container<?php echo $prompt->id;?>" class="updateprompt custom-dropdown-button">Publish</button>
    </form>
	</div>

            </div>
		

		<?php }else{?>
			
			<div class="popup-container" id="popup-container<?php echo $prompt->id;?>" style="display: none;">
			  <span onclick="document.getElementById('popup-container<?php echo $prompt->id;?>').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
    <h2>Add New Prompt</h2>
	<div id="resposne"></div>
    <form id="prompt-form" method="POST">
        
        <input type="text" id="prompt-title" value="<?php echo $prompt->prompt_title;?>" name="prompt_title" required placeholder="Prompt Title">
<br>
        <label for="prompt-category">Prompt Category </label>
       <input type="text" name="" value="<?php echo $prompt_category_text;?>">
		<br><br>
	<label>Prompt</label>
     <textarea name="prompt_text" id="prompt_text" placeholder="Text"><?php echo $prompt_text;?></textarea><br> 
       
    </form>
	</div>

			
            </div> <?php } ?></td></span>
				
		
			<?php
	    }
} else {
    // No prompts found
    echo "No prompts found in the database.";
}
?>	
<div id="prompt-popup" style="display: none;">
  <span onclick="document.getElementById('prompt-popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
    <h2>Add New Prompt</h2>
	<div id="resposne"></div>
    <form id="prompt-form" method="POST">
        
        <input type="text" id="prompt-title" name="prompt_title" required placeholder="Prompt Title">
<br>
        <label for="prompt-category">Prompt Category </label>
        <select id="prompt_category" name="prompt_category">
		    <option value="" selected>Choose Category</option>
             <option value="1" >Create Posts</option>
            <option value="2">Rewrite Posts</option>
			<option value="3">Comments Posts</option>
			<option value="4">Translate Posts</option>
			<option value="5">Rewrite Products</option>
			<option value="6">Reviews Products</option>
			<option value="7">Translate Product</option>
            <!-- Add more options as needed -->
        </select>
		<br><br>
		<div id="placeholder1" style="display:none">
		<h2>Use this placeholder</h2>
		<p>Use Placeholder&nbsp;[[keyword]] e.g "Write post content for "[[keyword]]". Must include introduction, table of content, pros and cons and FAQs. Use keyword in title and subheadings".</p>
		</div>
		<div id="placeholder2" style="display:none">
		<h2>Use this placeholder</h2>
		<p>Use Placeholder&nbsp;[[post_title]],&nbsp;[[post_content]] e.g<br>
		Rewrite the post title  [[post_title]] attractive to human<br>
		Rewrite the post content which is "[[post_content]]" and give the content in paragraph with heading<br>
		Rewrite the post title  where post title is "[[post_title]]" and post content is "[[post_content]]" , the new content should atleast one word of "Speed optimazation"</p>
		</div>
		<div id="placeholder3" style="display:none">
		<h2>Use this placeholder</h2>
		<p>Use &nbsp;[[post_title]],&nbsp;[[post_content]] e.g "Give the feed back of post and feedback should be related to content where content is [[post_content]]"</p>
		</div>
		<div id="placeholder4" style="display:none">
		<h2>Prompt sample</h2>
		<p>eg:Translate the post into chinese language</p>
		</div>
		<div id="placeholder5" style="display:none">
		<h2>Use this placeholder</h2>
		<p>Use &nbsp;[[product_title]],&nbsp;[[product_description]] e.g<br>
		Rewrite the Product title  [[product_title]] attractive to human<br>
		Rewrite the product description  and the content is "[[product_description]]" and give the content in paragraph with heading<br>
		Rewrite the post title  where post title is "[[product_title]]" and post content is "[[product_description]]" , the new content should atleast one word of "Speed optimization"</p>
		</div>
		<div id="placeholder6" style="display:none">
		<h2>Use this place holder</h2>
		<p>Use &nbsp;[[product_title]],&nbsp;[[product_description]] e.g
		Give the feedback of Product and feedback should be related to content where product description is "[[product_description]]"<br>
		</p>
		</div>
		<div id="placeholder7" style="display:none">
		<h2>Prompt sample</h2>
		<p>eg:Translate the Product into chinese language</p>
		</div>
		<label>Prompt</label>
     <textarea name="prompt_text" id="prompt_text" placeholder="Text"></textarea><br> 
        <button type="button" id="promptpubllish"  class="custom-dropdown-button">Publish</button>
    </form>
	</div>
</div>

<div id="plugin_activation_popup" style="display: none;">
  <span onclick="document.getElementById('plugin_activation_popup').style.display='none'"
      class="w3-button w3-display-topright">&times;</span>
<div class="popup-wrap">
   <div class="logo" style="text-align:center">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
		<h2>Please activate the plugin by using your license key,<br> Click below button</h2>
	<a href="<?php echo site_url();?>/wp-admin/admin.php?page=chatgpt-license-settings" class="activate_plugin">Activate Plugin</a>
	</div>
</div>


<style>
.success {
    color: green;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
    padding: 14px 0px;
}
.error{
	color:red; 
	text-align: center;
    font-size: 16px;
    font-weight: bold;
    padding: 14px 0px;
	}
div#delete-response {
    color: green;
    text-align: center;
    font-size: 16px;
    font-weight: bold;
}
input.record-checkbox {
    margin-top: 0px;
}
#prompt .popup-container .popup-content {
    width: 46%;
    background: #fff;
    margin: 3% auto;
    border-radius: 7px;
    padding: 30px;
    font-size: 18px;
    line-height: 29px;
}
a.view-post {
    padding-top: 1px; 
    display: block;
}
#prompt .header span:nth-child(1){width:33%;}
#prompt .header span:nth-child(2){width:26%;}
#prompt .header span:nth-child(3){width:10%;}
#prompt .header span:nth-child(4){width:5%;}
#prompt .header span:nth-child(5){width:5%;}


#prompt .data-row span:nth-child(1){width:33%;}
#prompt .data-row span:nth-child(2){width:26%;}
#prompt .data-row span:nth-child(3){width:10%;}
#prompt .data-row span:nth-child(4){width:5%;}
#prompt .data-row span:nth-child(5){width:5%;}
.popup-container .close-popup {
    color: #fff;
    font-size: 42px;
    float: right;
    margin-right: -100px;
    cursor: pointer;
}
</style>
	
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script>
jQuery(document).ready(function($) {
	   $("#prompt_category").on("change", function() {
                var selectedOption = $(this).val();
			
                
                // Hide all placeholder divs
                $("div[id^='placeholder']").css('display','none');
                
                // Show the corresponding placeholder div based on the selected option
                $("#placeholder" + selectedOption).css('display','block');
            });
			
			
	$("#promptpubllish").on("click", function(e) {		
    
        e.preventDefault();

        // Get the values from the input fields
        var promptTitle = $('#prompt-popup #prompt-title').val();
        var promptCategory = $('#prompt-popup #prompt_category').val();
        var promptText = $('#prompt-popup #prompt_text').val();

        // Check if any of the fields are empty
        if (!promptTitle || !promptCategory || !promptText) {
            alert('Please fill in all required fields.');
            return; // Prevent the AJAX request if any field is empty
        }

        var formData = {
            'action': 'save_prompt_data', // AJAX action
            'prompt_title': promptTitle,
            'prompt_category': promptCategory,
            'prompt_text': promptText
        };

        $.ajax({
            type: 'POST',
            url: cgpt_posts.ajaxurl,
            data: formData,
            success: function(response) {
                // Handle the response
				
                if (response.success) {
					$('#prompt-popup #resposne').html('<div class="success">Prompt added successfully</div>');
                    // If data is saved successfully, add a new data row
                   var newRow = '<div class="data-row" id="row'+response.data.prompt_id +'">' +
    '<span>' + response.data.prompt_title + '</span>' +
    '<span>' + response.data.prompt_category + '</span>' +
	 '<span>'+ '<a class="view-post" id="popup'+response.data.prompt_id +'">View Post</a>' +'</span>' +
	 '<span>' + response.data.prompt_auth + '</span>' +
    '<span class="checkbox"><td><input type="checkbox" class="record-checkbox" value="' + response.data.prompt_id + '"></td></span>' +
    '</div>';

 $('.header').after(newRow);
    setTimeout(function() {
     $('#prompt-popup').hide(); // Replace 'your-div-id' with the ID of your div
     }, 300);
                    // Clear the input fields
                    $('#prompt-title').val('');
                    $('#prompt-category').val('');
                    $('#prompt_text').val('');
                } else {
					$('#resposne').html('<div class="error">Failed to save data. Please try again.</div>');
                    
                }
            }
        });
    });


    // Handle the "Publish" button click
    $('.updateprompt').on('click', function(event) {
        event.preventDefault(); // Prevent the form from submitting normally

        // Get the data-popupid attribute from the button
        var popupid = $(this).data('popupid');
        
        // Find the form fields within the specified container
        var container = $('#' + popupid);
        var promptTitle = container.find('#prompt-title').val();
        var promptCategory = container.find('#prompt-category').val();
        var promptText = container.find('#prompt_text').val();
        var promptId = container.find('input[name="id"]').val(); // Assuming you have an input field for ID

        // Prepare the data to be sent via Ajax
        var formData = {
            action: 'update_prompt',
            popupid: popupid,
            promptTitle: promptTitle,
            promptCategory: promptCategory,
            promptText: promptText,
            promptId: promptId
        };

        // Make an Ajax request to update the prompt
        $.ajax({
            type: 'POST',
            url: cgpt_posts.ajaxurl,// Use the WordPress Ajax URL
            data: formData,
            success: function(response) {
             // Debugging: Check if the response is received
            console.log('Response received:', response);
           container.find('#response').html(response.message);
		   //alert(container);Prompt Updated Successfully
		   // Handle the server's response here
           //$(container + ' #response').html(response);
            },
            error: function(error) {
                console.error('Error:', error);
            }
        });
    });


   	 // Check All checkbox
    $('#check-all').change(function() {
        $('.record-checkbox').prop('checked', $(this).prop('checked'));
    });

    // Delete Selected button
    $('#delete-selected').click(function() {
        var selectedIds = [];

        // Loop through checked checkboxes and store their values (record IDs)
        $('.record-checkbox:checked').each(function() {
            selectedIds.push($(this).val());
        });

        if (selectedIds.length > 0) {
            // Send AJAX request to delete selected records
            $.ajax({
                type: 'POST',
                url: cgpt_posts.ajaxurl,
                data: {
                    action: 'delete_selected_prompts',
                    prompt_ids: selectedIds
                },
                success: function(response) {
                    // Handle the response (e.g., refresh the page)
                    //alert(response);
                    //location.reload();
selectedIds.forEach(function(id) {
    $("#row" + id).animate({
        marginLeft: '-100%', // Adjust the value as needed to control the animation
        opacity: 0
    }, 500, function() {
        // Remove the element from the DOM after the animation is complete
        $(this).remove();
    });
});

$('#delete-response').html(response);
                }
            });
        } else {
            alert('Please select at least one record to delete.');
        }
    });



	 $('#prompt').on('click', 'a.view-post', function (e) {
        e.preventDefault();

        // Extract the post ID from the link's ID
        const postId = $(this).attr('id').split('popup')[1];
		

        // Show the corresponding popup container
        $('#popup-container' + postId).show();
    });

    // Event listener for the "Close" buttons
    $('#prompt').on('click', 'span.close-popup', function () {
        $(this).closest('.popup-container').hide();
    });
	
	$('#prompt').on('click', '.custom-dropdown-button', function () {
        $(this).closest('.popup-container').hide();
    });
	
$('#add-prompt').click(function(e) {
    e.preventDefault();
    
    var shouldProceed = '1<?php echo get_option( 'chatgpt_client_activated' );?>'; 
	
	if(shouldProceed == ''){
		$('#plugin_activation_popup').show();
		return;
		}
               $('#prompt-popup').show(); // Show the prompt popup 
			
       
    });


});



</script>

<style>
div#response {
    color: green;
    font-size: 18px;
    text-align: center;
    padding-bottom: 13px;
    font-weight: bold;
}</style>