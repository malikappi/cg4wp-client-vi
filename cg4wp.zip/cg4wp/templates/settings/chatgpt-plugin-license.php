<?php

/**
 * Plugin settings page class.
 */
class ChatGPT_Settings_License {

	/**
	 * Initialize the settings page.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_settings_page' ] );
		add_action( 'admin_init', [ $this, 'initialize_settings' ] );
		
		//add_action( 'admin_post_save_chatgpt_license', [
		//	$this,
		//	'handle_form_submission',
		//] );
		
		
		add_action( 'wp_ajax_handle_form_submission', [
			$this,
			'handle_form_submission',
		] );
		
		add_action( 'wp_ajax_handle_chatgpt_apikey_verification', [
			$this,
			'handle_chatgpt_apikey_verification',
		] );
	
	}

	/**
	 * Add settings page to the admin menu under "Settings".
	 */
	public function add_settings_page(): void {
    add_menu_page(
        'ChatGPT 4 WordPress Settings',
        'CG4WP Settings',
        'manage_options',
        'chatgpt-license-settings',
        [ $this, 'render_settings_page' ],
        'dashicons-admin-generic',
        99
    );

    add_submenu_page(
        'chatgpt-license-settings',
        'CG4WP Prompts',
        'Prompt Library',
        'manage_options',
        'chatgpt-prompts-page', // Updated submenu slug
        [ $this, 'render_prompts_page' ], // Updated callback function
        100
    );
}

    public function render_prompts_page() {
    // Add your submenu page content here
    echo '<div class="wrap">';
   
     require_once PLUGIN_PATH . 'templates/prompt/chatgpt-prompt-library.php';
    echo '</div>';
}
	


		
		
	public function render_settings_page(): void {
		$messages = [];
		if ( isset( $_GET['message'] ) && ! empty( $_GET['message'] ) ) {
			$messages[] = urldecode( $_GET['message'] );
		}

		 $license_key = get_option( 'chatgpt_license_key' );
         $plugin_dir = __DIR__;
         $image_url = plugin_dir_url( $plugin_dir ) . 'images/logo.png';
		 $loading = plugin_dir_url( $plugin_dir ) . 'images/loading.gif';
?>
		  <header>
		 
        <div class="logo">
            <img src="<?php echo esc_url($image_url); ?>" alt="Logo">
        </div>
	<?php

?>
<div class="packagewrap" style="float:right">
<?php if(!get_option('chatgpt_product_name',false) == ''){?>
<div class="plandetail"><span style="color:#000;">Plan </span>: <?php echo get_option('chatgpt_product_name',false);?></div>
<?php } ?>

		 <div class="update-button">
            <a href="https://chatgpt4wordpress.com/pricing/">Upgrade Your Plan</a>
        </div>
	
	</div>
    </header>
	<main class="verfication" style="min-height:600px">
        <div class="api-form">
		
		
				<div class="chatgpt-settings-page-heading">
					<h1>
						<?php echo __( 'Settings', 'chatgpt' ); ?>
					</h1>
				</div>

				<?php
				if ( ! empty( $messages ) ) {
					foreach ( $messages as $message ) {
						echo '<div class="notice notice-success is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
					}
				}
				?>
				
				<form id="api-key-form" method="post"
				      action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="width:600px">
					<?php
					settings_fields( 'chatgpt_settings_group' );
					$input_disabled = $license_key ? 'disabled' : '';
					?>
					<p>  </p>

					<h3 style="margin-bottom: 0px;clear:both">
						<?php echo __( 'Plugin License Key', 'chatgpt' ); ?>
					</h3>
					 <div class="field">   <label for="license-key">License Key</label>
		   <small><?php echo __( 'Please enter the Plugin License key and the CHATGPT API Key. Please note that the ChatGPT API key should correct otherwise the plugin will not work.' ) ?></small>
			<div style="position:relative">		<input type="text" id="chatgpt_license_key" name="chatgpt_license_key"
					       value="<?php echo esc_attr( $license_key ); ?>"
					       <?php //echo $input_disabled; ?> placeholder="Enter your License Key">
						    <span class="tooltip" data-tooltip="Plugin License key">?</span>
							</div>
</div>
<div id="license-message"></div>
<?php 
	if(empty($license_key)) {
    echo '<input type="submit" name="submit" id="save_license_btn"
           class="button button-primary"
           value="Save License"><img class="loading1" src="' . $loading . '" width="30">';
    echo '<input type="hidden" name="action" id="action" value="save_cg4wp_license">';
} else  {
    echo '<input type="submit" name="submit" id="update_license_btn"
           class="button button-primary"
           value="Update License"><img class="loading1" src="' . $loading . '" width="30">';
    echo '<input type="hidden" name="action" id="action" value="update_cg4wp_license">';
}

if (get_option( 'unlimited_product') == 'yes' ){$showfield = 'style="display:block"';}else{$showfield = 'style="display:none"';}
?>
    <div class="field" id="chatgpt_api_key" <?php echo $showfield;?>>
    <label for="api-key">ChatGpt API Key</label>
    <small>Please Update your ChatGpt API key (<a href="www.loremipsum.com" target="_blank">How to get your own ChatGpt API key</a>)</small>
    <div style="position:relative">
    <input placeholder="Enter your Chatgpt API Key" type="text" id="chatgpt_api_key_field" name="chatgpt_api_key" value="<?php if(get_option( 'unlimited_product') == 'yes')
	{  $chatgpt_api_key = get_option('chatgpt_api_key');
        if($chatgpt_api_key){echo $masked_string = $this->hide_sensitive_data($chatgpt_api_key);}
	  }else{
		     $chatgpt_api_key = get_option('chatgpt_api_key');
			 if($chatgpt_api_key){echo $masked_string = $this->hide_sensitive_data($chatgpt_api_key);}
		
		} 
?>">
    <span class="tooltip" data-tooltip="Add the ChatGpt API Key">?</span>
    </div>
	<div id="api-key-message"></div>	
<?php 
	
if( get_option('chatgpt_api_key') == '') {
    echo '<input type="submit" name="submit" id="save_chatgpt_apikey_btn"
           class="button button-primary"
           value="Save Chatgpt API Key" style="float:left"><img class="loading2" src="' . $loading . '" width="30">';
    echo '<input type="hidden" name="action" id="action" value="save_chatgpt_apikey">';
}else{
	 echo '<input type="submit" name="submit" id="save_chatgpt_apikey_btn"
           class="button button-primary"
           value="Update Chatgpt API Key" style="float:left"><img class="loading2" src="' . $loading . '" width="30">';
    echo '<input type="hidden" name="action" id="action" value="save_chatgpt_apikey">';
}
//endif;
					?>
    </div>
<div style="width:100%">
<?php
if ($license_key) {
    echo '<br>';
    echo '<em>' . esc_html__('ChatGPT 4 WordPress plugin License is activated.', 'chatgpt') . '</em>';
}
?>
	</div>					
	<br>	

				</div>
			</div>
		</div>
		
	<script>
	jQuery(document).ready(function($) {
	
		
    // Listen for form submission
$('#save_license_btn').on('click', function(e) {
		e.preventDefault(); // Prevent the default form submission
    update_cg4wp_license();
});
	
	
$('#update_license_btn').on('click', function(e) {
        e.preventDefault(); // Prevent the default form submission
        update_cg4wp_license();
});
	
	
$('#save_chatgpt_apikey_btn').on('click', function(e) {
		
        e.preventDefault(); // Prevent the default form submission
        saveChatGptApiKey();
});


function update_cg4wp_license() {
    // Get the API key from the form or any other relevant source
    var apiKey = $('#chatgpt_license_key').val();
   $('.loading1').show();
    // Make an AJAX request
    $.ajax({
        url: cgpt_posts.ajaxurl, // Replace with the actual URL of your AJAX endpoint
        type: 'POST',
        data: {
            action: 'handle_form_submission', // Action hook for your server-side code
            chatgpt_license_key: apiKey
        },
             success: function(response) {
				 console.log(response);
				 
            if (response.errors === 'Yes') {
                $('.loading1').hide();
                $('#license-message').html('<span style="color:red; font-weight:bold">' + response.message + '</span>');
            } else {
                $('.loading1').hide();
				if(response.api_field == 1){ 
				$('#chatgpt_api_key_field').val('');
				$('#chatgpt_api_key').show();
				}else{
					$('#chatgpt_api_key').hide();
					$('#chatgpt_api_key_field').val('');
                $('#license-message').html('<span style="color:green; font-weight:bold">' + response.message + '</span>');
				}
                
            }
        },
        error: function() {
            $('.loading1').hide();
            $('#license-message').html('<span style="color:red; font-weight:bold">Error in code</span>');
        }
    });
}

    function saveChatGptApiKey() {
        // Get the API key from the form or any other relevant source
        var apiKey = $('#chatgpt_api_key_field').val();
		$('.loading2').show();
		
        // Make an AJAX request
        $.ajax({
            url: cgpt_posts.ajaxurl, // Replace with the actual URL of your AJAX endpoint
            type: 'POST',
            data: {
                action: 'handle_chatgpt_apikey_verification', // Action hook for your server-side code
                chatgpt_api_key: apiKey
            },
            success: function(response) {
				console.log(response);
				if(response.message == 'success'){
					var inputValue = apiKey;
                    var visiblePart = inputValue.slice(-4);
                    var hiddenPart = "*".repeat(inputValue.length - 4);
                    var maskedValue = hiddenPart + visiblePart;
                        $('#chatgpt_api_key_field').val(maskedValue);
					$('.loading2').hide();
					jQuery('#api-key-message').html('<span style="color:green;font-weight:bold">API Key is valid and has been saved</span>');
				}else{
					$('.loading2').hide();
					jQuery('#api-key-message').html('<span style="color:red;font-weight:bold">API Key is invalid</span>');
				}
                
           
            },
            error: function() {
				$('.loading2').hide();
                jQuery('#api-key-message').html('<span style="color:red;font-weight:bold">API Key is invalid</span>');
            }
        });
    }

	
});


</script>	
	<?php
	}


	/**
	 * Handle form submission and API verification.
	 */
	public function handle_form_submission(){
		if ( isset( $_POST['chatgpt_license_key'] )  ) {
			
			$license_key  = sanitize_text_field( $_POST['chatgpt_license_key'] );
			 $api_response = $this->verify_license_key_with_api( $license_key );
			 
			 
			 
			if ( $api_response !== NULL ) {
				
				if ( $api_response->action == 'required' ) {
					$error_message = $api_response->message;
					$response_data = array(
                    'message' => $error_message,
					'errors' => 'Yes',);
                     wp_send_json($response_data);
				}

				if ( $api_response->action == 'approved' ) {
					$success_message   = $api_response->message;
					$allowed_install   = $api_response->allowed_install;
					$product_name      = $api_response->product_name;
					$allowed_usuage    = $api_response->allowed_usuage;
					$remaining_usuage  = $api_response->remaining_usuage;
					$allowed_days      = $api_response->allowed_days;
					$start_date        = $api_response->start_date;
					$expiry_date       = $api_response->expiry_date;
					$chatgpt_api_key   = $api_response->chatgpt_api_key;
					$status   = $api_response->status;
					
				    
					if($chatgpt_api_key == ''){
						update_option( 'chatgpt_api_key', '' );
						update_option( 'unlimited_product', 'yes' );
						$show_chatgptapi_field = 1;
						
						}else{
							update_option( 'chatgpt_api_key', $chatgpt_api_key );
							update_option( 'unlimited_product', 'no' );
							$show_chatgptapi_field = 0;
						
						}
				    
					update_option( 'chatgpt_license_key', $license_key );
					update_option( 'chatgpt_product_name', $product_name );
					update_option( 'chatgpt_allowed_install', $allowed_install );
					update_option( 'chatgpt_allowed_usage', $allowed_usuage );
					update_option( 'chatgpt_remaining_usuage', $remaining_usuage );
					update_option( 'chatgpt_start_date', $start_date );
					update_option( 'chatgpt_expiry_date', $expiry_date );
					update_option( 'chatgpt_license_status', $status );
					
					
					update_option( 'chatgpt_client_activated', TRUE );
					
					$response_data = array(
					'api_field' => $show_chatgptapi_field,
					'chatgpt_api' => $chatgpt_api_key,
                    'message' => $success_message,);
                     wp_send_json($response_data);
				}
			
			
			} else {
				$error_message = 'Error: Failed to get API response.';
				$response_data = array(
                    'message' => $error_message,);
                     wp_send_json($response_data);
			}
		
		
}
	}

	/**
	 * Handle Chatgpt API verification.
	 */
	public function handle_chatgpt_apikey_verification() {
		if ( isset( $_POST['chatgpt_api_key'] ) ) {
			$api_key      = $_POST['chatgpt_api_key'];
			
			$api_url = 'https://api.openai.com/v1/engines/davinci/completions';
    
    $data = array(
        'prompt' => 'This is a test.', // You can use any prompt for the test
        'max_tokens' => 5, // You can adjust this as needed
    );

    $headers = array(
        'Content-Type: application/json',
        'Authorization: Bearer ' . $api_key,
    );

    $ch = curl_init();
    
    curl_setopt($ch, CURLOPT_URL, $api_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
    
    $response = curl_exec($ch);
    
    if (curl_errno($ch)) {
        $error_message = 'cURL Error: ' . curl_error($ch);
    } else {
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($http_code === 200) {
            // API key is valid
            update_option('chatgpt_api_key', $api_key);
			update_option( 'chatgpt_api_key_added', 1 );
            $response_data = array(
            'message' => 'success',);
            wp_send_json($response_data);
			
        } else {
			
            // API key is invalid or not authorized
            $error_message = 'Invalid API Key. HTTP Code: ' . $http_code;
			$response_data = array(
            'message' => 'error',);
             wp_send_json($response_data);
        }
    }
	
		
		}
		
	}
	
	/**
	 * Initialize the settings and fields.
	 */
	public function initialize_settings(): void {
		// Register the settings
		register_setting( 'chatgpt_settings_group', 'chatgpt_license_key' );

		add_settings_section(
			'chatgpt_settings_section',
			'Plugin Settings',
			[ $this, 'chatgpt_settings_section_callback' ],
			'chatgpt-license-settings'
		);
	}

	/**
	 * Callback function for the settings section.
	 */
	public function chatgpt_settings_section_callback(): void {
		?>
		<strong>
			<?php echo __( 'Enter your ChatGPT license key: ', 'chatgpt' ); ?>
		</strong>
		<?php
	}
	
	/**
	 * Helper function to verify the license key with the server-side API.
	 *
	 * @param string $license_key The license key to verify.
	 *
	 */
	private function verify_license_key_with_api( string $license_key ): stdClass  {
		$api_url  = CHATGPT_SERVER_URL . '/license-auth';
		$site_url = get_site_url();

		$response = wp_remote_post( $api_url, [
			'method'  => 'POST',
			'headers' => [
				'Content-Type' => 'application/json',
			],
			'body'    => json_encode( [
				'api_key'  => $license_key,
				'site_url' => $site_url,
			] ),
		] );

		return json_decode( wp_remote_retrieve_body( $response ) );
		
	}



    private function chatgpt_import_prompt() : void{
        global $wpdb;
	    echo $csv_file_path = plugin_dir_path(__FILE__) . 'prompts_library.csv';
    
        $author_to_delete = 'system';

        // Define the table name
        $table_name = $wpdb->prefix . 'prompts_library';

    // First, delete prompts where the author is "system"
    $sql = $wpdb->prepare("DELETE FROM $table_name WHERE auth = %s", $author_to_delete);
    $wpdb->query($sql);

    // Check if the CSV file exists
    if (file_exists($csv_file_path)) {
        // Open and read the CSV file
        if (($handle = fopen($csv_file_path, 'r')) !== false) {
            while (($data = fgetcsv($handle, 1000, ',')) !== false) {
                // Extract data from CSV
                $prompt_title = $data[0];
                $prompt_category = $data[1];
                $prompt_text = $data[2];
                $auth = $data[3];

                // Insert data into the database
                $wpdb->insert(
                    $table_name,
                    array(
                        'prompt_title' => $prompt_title,
                        'prompt_category' => $prompt_category,
                        'prompt_text' => $prompt_text,
                        'auth' => $auth,
                    )
                );
            }
            fclose($handle);
        } else {
            // Handle file reading error
        }
    } else {
        // Handle file not found error
    }
}

    private function hide_sensitive_data($data) {
    $length = strlen($data);
    $visible_part = substr($data, -4);
    $hidden_part = str_repeat('*', $length - 4);
    
    return $hidden_part . $visible_part;
}

}

new ChatGPT_Settings_License();

if ( isset( $_POST['chatgpt_api_key'] ) ) {
	if ( ! empty( $api_key ) ) {
		$api_key = sanitize_text_field( $_POST['chatgpt_api_key'] );

		update_option( 'chatgpt_api_key', $api_key );
	}
}